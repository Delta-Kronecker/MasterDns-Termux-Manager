#!/data/data/com.termux/files/usr/bin/bash
# =============================================================================
# MasterDnsVPN Client Manager – Main Script v3.7.3
# =============================================================================

set +e +u

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
MASTER_DNS_DIR="$SCRIPT_DIR/Configuration"

RESOURCES_FILE="$SCRIPT_DIR/masterdns_resources.sh"
if [[ ! -f "$RESOURCES_FILE" ]]; then
    printf '\e[1;31mError: masterdns_resources.sh not found.\e[0m\n'
    exit 1
fi
source "$RESOURCES_FILE"

if [[ ! -d "$MASTER_DNS_DIR" ]]; then
    printf "%b\n" "$ERR_FOLDER_NOT_FOUND"
    exit 1
fi

cd "$MASTER_DNS_DIR"

cleanup_on_exit() {
    kill_all_clients 2>/dev/null || true
    show_cursor
    clear_screen
    exit 0
}
trap cleanup_on_exit INT TERM
hide_cursor

#######################################
# 1. Paths & constants
#######################################

CLIENT_BIN=""
for bin in MasterDnsVPN_Client_Termux_ARM64* MasterDnsVPN_Client_Termux_ARM64 MasterDnsVPN_Client*; do
    [[ -f "$bin" && -x "$bin" ]] && { CLIENT_BIN="./$bin"; break; }
done
[[ -z "$CLIENT_BIN" ]] && CLIENT_BIN="./MasterDnsVPN_Client_Termux_ARM64"

CONFIG_FILE="./client_config.toml"
RESOLVERS_FILE="./client_resolvers.txt"

DEFAULT_CONFIG="./Default.toml"
MTU_BRUTE_BURST="./mtu-brute-burst.toml"
BUFFER_SMART_ULTRA="./buffer-smart-ultra.toml"
SCAN_POOL_STABLE="./scan-pool-stable.toml"
STEADY_POOL_CERTIFIED="./steady-pool-certified.toml"
PURE_SPEED_BLADE="./pure-speed-blade.toml"
IRONCLAD_SURVIVOR="./ironclad-survivor.toml"
UNIVERSAL_HARMONY="./universal-harmony.toml"

PID_FILE="$PWD/client.pid"
LOG_FILE="$PWD/client.log"
LOG_BACKUP="$PWD/client.log.old"
PROFILES_DIR="$PWD/profiles"
MULTI_DIR="$PWD/multi_connection"
MTU_TEST_DIR="$PWD/mtu_test"
AUTO_MTU_FLAG="$PWD/auto_mtu_parallelism.flag"
PARALLELISM_FILE="$PWD/parallelism_percent.txt"
RESOLVER_LISTS_DIR="$PWD/resolver_lists"
SCANNER_DIR="$PWD/scanner"

mkdir -p "$PROFILES_DIR" "$RESOLVER_LISTS_DIR"

declare -A TEMPLATE_NAMES_MAP=(
    [0]="Default"
    [1]="mtu-brute-burst"
    [2]="buffer-smart-ultra"
    [3]="scan-pool-stable"
    [4]="steady-pool-certified"
    [5]="pure-speed-blade"
    [6]="ironclad-survivor"
    [7]="universal-harmony"
)

declare -A TEMPLATE_FILES_MAP=(
    [0]="$DEFAULT_CONFIG"
    [1]="$MTU_BRUTE_BURST"
    [2]="$BUFFER_SMART_ULTRA"
    [3]="$SCAN_POOL_STABLE"
    [4]="$STEADY_POOL_CERTIFIED"
    [5]="$PURE_SPEED_BLADE"
    [6]="$IRONCLAD_SURVIVOR"
    [7]="$UNIVERSAL_HARMONY"
)

declare -A OLD_TO_NEW_MAP=(
    ["./high-mtu-window-blast.toml"]="$MTU_BRUTE_BURST"
    ["./deep-buffer-balanced-ultra.toml"]="$BUFFER_SMART_ULTRA"
    ["./stable-scan-daily-driver.toml"]="$SCAN_POOL_STABLE"
    ["./curated-pool-steady.toml"]="$STEADY_POOL_CERTIFIED"
    ["./velocity-max-download.toml"]="$PURE_SPEED_BLADE"
    ["./iron-steadfast-survival.toml"]="$IRONCLAD_SURVIVOR"
    ["./omni-balance.toml"]="$UNIVERSAL_HARMONY"
)

for old_file in "${!OLD_TO_NEW_MAP[@]}"; do
    new_file="${OLD_TO_NEW_MAP[$old_file]}"
    if [[ -f "$old_file" && ! -f "$new_file" ]]; then
        ln -sf "$(basename "$old_file")" "$new_file" 2>/dev/null
    fi
done

#######################################
# 2. Helper functions
#######################################

check_resolvers_warning() {
    if [[ ! -f "$RESOLVERS_FILE" || ! -s "$RESOLVERS_FILE" ]]; then
        printf "\n${YELLOW}⚠ WARNING: No resolvers found in $RESOLVERS_FILE${NC}\n"
        printf "${WHITE}You can add resolvers via Menu → Resolvers (option 4).${NC}\n"
    fi
}

edit_file_with_education() {
    local file="$1"
    show_editor_education
    clear_screen
    if command -v nano &>/dev/null; then
        nano "$file"
    else
        printf "%b\n" "$ERR_NANO_NOT_FOUND"
        press_enter
    fi
}

count_resolvers() {
    [[ -f "$RESOLVERS_FILE" ]] && grep -cve '^\s*$' "$RESOLVERS_FILE" 2>/dev/null || echo 0
}

PARALLELISM_PERCENT=10
calculate_parallelism() {
    local c=$1
    local v=$(( (c * PARALLELISM_PERCENT + 99) / 100 ))
    [[ $v -lt 1 ]] && v=1
    echo "$v"
}

update_active_config_parallelism() {
    local v=$1
    [[ -f "$CONFIG_FILE" ]] && sed -i "s|^MTU_TEST_PARALLELISM = .*|MTU_TEST_PARALLELISM = $v|" "$CONFIG_FILE" 2>/dev/null
}

update_all_configs_parallelism() {
    local c=$(count_resolvers)
    local v=$(calculate_parallelism "$c")
    update_active_config_parallelism "$v"
    echo "$v"
}

set_auto_parallelism() {
    local state=$1
    echo "$state" > "$AUTO_MTU_FLAG"
    [[ "$state" == "yes" ]] && update_all_configs_parallelism >/dev/null
}

auto_parallelism_enabled() {
    [[ -f "$AUTO_MTU_FLAG" ]] && grep -q "yes" "$AUTO_MTU_FLAG" 2>/dev/null && return 0
    return 1
}

show_parallelism_setup() {
    clear_screen
    printf "%b\n\n" "$PARALLELISM_SETUP_HEADER"
    printf "%b" "$PARALLELISM_SETUP_PROMPT"
    read -rsn1 ch
    case "$ch" in
        y|Y) set_auto_parallelism "yes"; printf "\n${GREEN}Enabled.${NC}\n" ;;
        h|H) show_help_screen "$PARALLELISM_HELP"; show_parallelism_setup; return ;;
        *) set_auto_parallelism "no"; printf "\n${YELLOW}Manual mode.${NC}\n" ;;
    esac
    sleep 1
}

draw_progress_bar() {
    local valid=$1 rejected=$2 total=$3 width=20
    [[ $total -le 0 ]] && total=1
    local tested=$(( valid + rejected ))
    local filled=$(( tested * width / total ))
    [[ $filled -gt $width ]] && filled=$width
    local empty=$(( width - filled ))
    local bar=""
    for ((i=0; i<filled; i++)); do bar+="█"; done
    for ((i=0; i<empty; i++)); do bar+="░"; done
    printf "Tested: [${CYAN}%s${NC}] %d/%d" "$bar" "$tested" "$total"
}

sanitize_toml() {
    local file="$1"
    sed -i '/^\s*=\s*$/d' "$file" 2>/dev/null
}

#######################################
# 3. Config validation
#######################################

has_valid_config() {
    [[ ! -f "$CONFIG_FILE" ]] && return 1
    local d=$(grep '^DOMAINS = \[' "$CONFIG_FILE" 2>/dev/null | sed -n 's/.*\["\(.*\)"\].*/\1/p')
    local k=$(grep '^ENCRYPTION_KEY = "' "$CONFIG_FILE" 2>/dev/null | sed -n 's/.*"\(.*\)".*/\1/p')
    [[ -z "$d" || -z "$k" || "$d" == "v.domain.com" || "$k" == *"smoke-test-key"* ]] && return 1
    return 0
}

get_domain_from_config() { grep '^DOMAINS = \[' "$CONFIG_FILE" 2>/dev/null | sed -n 's/.*\["\(.*\)"\].*/\1/p'; }
get_key_from_config()     { grep '^ENCRYPTION_KEY = "' "$CONFIG_FILE" 2>/dev/null | sed -n 's/.*"\(.*\)".*/\1/p'; }

#######################################
# 4. Process management
#######################################

is_running() {
    [[ -f "$PID_FILE" ]] && {
        pid=$(cat "$PID_FILE")
        kill -0 "$pid" 2>/dev/null && return 0 || { rm -f "$PID_FILE"; return 1; }
    } || return 1
}

proxy_ready() {
    is_running && grep -q 'SOCKS5 Proxy server is listening' "$LOG_FILE" 2>/dev/null && echo "yes" || echo "no"
}

get_valid()   {
    grep -E 'valid=[0-9]+' "$LOG_FILE" 2>/dev/null | tail -1 | sed -n 's/.*valid=\([0-9]\+\).*/\1/p' || echo 0
}
get_rejected(){
    grep -E 'rejected=[0-9]+' "$LOG_FILE" 2>/dev/null | tail -1 | sed -n 's/.*rejected=\([0-9]\+\).*/\1/p' || echo 0
}
get_active()  {
    local v=$(grep -E 'Total Active:|Remaining:' "$LOG_FILE" 2>/dev/null | tail -1 | sed -n 's/.*\(Total Active\|Remaining\): *\([0-9]\+\).*/\2/p')
    [[ -z "$v" ]] && v=$(get_valid)
    echo "$v"
}
get_stream()  {
    grep 'Stream ID:' "$LOG_FILE" 2>/dev/null | tail -1 | sed -n 's/.*Stream ID: *\([0-9]\+\).*/\1/p' || echo 0
}

kill_all_clients() {
    [[ -f "$PID_FILE" ]] && {
        kill "$(cat "$PID_FILE")" 2>/dev/null
        sleep 1
        kill -9 "$(cat "$PID_FILE")" 2>/dev/null
        rm -f "$PID_FILE"
    }
    pkill -f "$(basename "$CLIENT_BIN")" 2>/dev/null || true
    sleep 1
}

start_client() {
    if ! has_valid_config; then
        printf "\n${RED}load a profile first (6. Manage Profiles)${NC}\n"
        press_enter; return 1
    fi
    if [[ ! -f "${CLIENT_BIN#./}" ]] && [[ ! -f "$CLIENT_BIN" ]]; then
        printf "%b\n" "$ERR_BINARY_NOT_FOUND"; press_enter; return 1
    fi
    kill_all_clients
    chmod +x "$CLIENT_BIN" 2>/dev/null || true
    [[ -f "$LOG_FILE" ]] && mv -f "$LOG_FILE" "$LOG_BACKUP" 2>/dev/null || true
    > "$LOG_FILE"
    nohup "$CLIENT_BIN" -config "$CONFIG_FILE" < /dev/null >> "$LOG_FILE" 2>&1 &
    printf '%s' "$!" > "$PID_FILE"
    disown "$!"
    printf "\n${GREEN}Client started (PID %s).${NC}\n" "$(cat "$PID_FILE")"
    check_resolvers_warning
}

stop_client() {
    if is_running; then
        printf "%b\n" "$INFO_STOPPING"
        kill_all_clients
        > "$LOG_FILE"
        printf "%b\n" "$MSG_DONE"
    else
        printf "%b\n" "$ERR_CLIENT_NOT_RUNNING"
    fi
}

restart_client() {
    printf "%b\n" "$SETTINGS_RESTARTING"
    stop_client
    sleep 2
    start_client
}

show_log_view() {
    clear_screen
    printf "── Log (press Q to exit) ──\n\n"
    if [[ -f "$LOG_FILE" ]]; then
        tail -n 50 -f "$LOG_FILE" 2>/dev/null &
        local tp=$!
        while true; do
            read -s -n 1 -t 0.5 key 2>/dev/null
            [[ $? -eq 0 ]] || continue
            if [[ "$key" == "q" || "$key" == "Q" ]]; then
                kill "$tp" 2>/dev/null
                break
            fi
        done
        wait "$tp" 2>/dev/null
    else
        printf "No log.\n"
        press_enter
    fi
    clear_screen
}

#######################################
# 5. Profile management
#######################################

list_profiles() { ls -tr "$PROFILES_DIR" 2>/dev/null | grep '\.toml$' | sed 's/\.toml$//' || true; }
profile_exists() { [[ -f "$PROFILES_DIR/${1}.toml" ]]; }

create_single_profile() {
    local template_idx="$1" base_name="$2" domain="$3" key="$4"
    local template_file="${TEMPLATE_FILES_MAP[$template_idx]}"
    local template_name="${TEMPLATE_NAMES_MAP[$template_idx]}"
    local profile_name="${base_name}-${template_name}"

    [[ ! -f "$template_file" ]] && { printf "  ${RED}Template %s missing.${NC}\n" "$template_name"; return 1; }
    profile_exists "$profile_name" && { printf "  ${YELLOW}Skip existing: %s${NC}\n" "$profile_name"; return 0; }

    cp "$template_file" "$PROFILES_DIR/${profile_name}.toml"
    sanitize_toml "$PROFILES_DIR/${profile_name}.toml"
    sed -i "s|^DOMAINS = \[.*\]|DOMAINS = [\"$domain\"]|" "$PROFILES_DIR/${profile_name}.toml"
    sed -i "s|^ENCRYPTION_KEY = \".*\"|ENCRYPTION_KEY = \"$key\"|" "$PROFILES_DIR/${profile_name}.toml"
    [[ -f "$RESOLVERS_FILE" ]] && cp "$RESOLVERS_FILE" "$PROFILES_DIR/${profile_name}.resolvers.txt"
    printf "  ${GREEN}Created: %s${NC}\n" "$profile_name"
    return 0
}

create_all_profiles() {
    show_help_screen "${CYAN}══ Create All Profiles ══${NC}\nThis will create 8 profiles with the same domain/key."
    printf "\n${CYAN}══ Create All 8 Profiles ══${NC}\n\n"
    printf "%b\n" "$GET_BASE_NAME_PROMPT"; read -r base_name
    [[ -z "$base_name" ]] && { printf "%b\n" "$ERR_REQUIRED"; press_enter; return 1; }
    printf "\n${WHITE}Domain:${NC}\n> "; read -r domain
    [[ -z "$domain" ]] && { printf "%b\n" "$ERR_REQUIRED"; press_enter; return 1; }
    printf "\n${WHITE}Encryption Key:${NC}\n> "; read -r key
    [[ -z "$key" ]] && { printf "%b\n" "$ERR_REQUIRED"; press_enter; return 1; }

    printf "\n${GREEN}Creating profiles...${NC}\n\n"
    local created=0
    for idx in 0 1 2 3 4 5 6 7; do
        create_single_profile "$idx" "$base_name" "$domain" "$key" && ((created++))
    done
    printf "\n${GREEN}Created %d profiles.${NC}\n" "$created"
    press_enter
}

create_profile() {
    clear_screen; render_profile_screen
    has_valid_config || printf "\n%b\n" "$FIRST_RUN_RECOMMENDED"
    read -rsn1 tc
    case "$tc" in
        h|H) show_help_screen "$PROFILE_HELP"; create_profile; return ;;
        8) create_all_profiles; return ;;
        9) return ;;
    esac
    if [[ ! "$tc" =~ ^[0-7]$ ]]; then
        printf "\n%b\n" "$ERR_INVALID_CHOICE"; press_enter; return 1
    fi

    local template_file="${TEMPLATE_FILES_MAP[$tc]}"
    local template_name="${TEMPLATE_NAMES_MAP[$tc]}"
    [[ ! -f "$template_file" ]] && { printf "\n${RED}Template %s missing.${NC}\n" "$template_name"; press_enter; return 1; }

    printf "\n${WHITE}Profile name:${NC}\n> "; read -r name
    [[ -z "$name" ]] && { printf "%b\n" "$ERR_REQUIRED"; press_enter; return 1; }
    printf "\n${WHITE}Domain:${NC}\n> "; read -r domain
    [[ -z "$domain" ]] && { printf "%b\n" "$ERR_REQUIRED"; press_enter; return 1; }
    printf "\n${WHITE}Encryption Key:${NC}\n> "; read -r key
    [[ -z "$key" ]] && { printf "%b\n" "$ERR_REQUIRED"; press_enter; return 1; }

    cp "$template_file" "$CONFIG_FILE"
    sanitize_toml "$CONFIG_FILE"
    sed -i "s|^DOMAINS = \[.*\]|DOMAINS = [\"$domain\"]|" "$CONFIG_FILE"
    sed -i "s|^ENCRYPTION_KEY = \".*\"|ENCRYPTION_KEY = \"$key\"|" "$CONFIG_FILE"
    cp "$CONFIG_FILE" "$PROFILES_DIR/${name}.toml"
    [[ -f "$RESOLVERS_FILE" ]] && cp "$RESOLVERS_FILE" "$PROFILES_DIR/${name}.resolvers.txt"

    auto_parallelism_enabled && { local v=$(update_all_configs_parallelism); printf "\n"$MSG_PAR_UPDATED"\n" "$v"; }
    printf "\n"$MSG_DONE"\n"; press_enter
}

load_profile() {
    clear_screen; printf "%b\n\n" "$LOAD_PROFILE_HEADER"
    local profiles=($(list_profiles))
    if [[ ${#profiles[@]} -eq 0 ]]; then
        printf "%b\n" "$ERR_NO_PROFILES"; press_enter; return
    fi
    is_running && { printf "%b\n" "$INFO_STOPPING"; stop_client; }
    printf "Available profiles:\n\n"
    printf "%-3s %-30s\n" "#" "Name"
    printf "──────────────────────────────\n"
    for i in "${!profiles[@]}"; do printf "  %-2d %-30s\n" $((i+1)) "${profiles[$i]}"; done
    printf "\n  %-2d Back\n\n" $(( ${#profiles[@]} + 1 ))
    printf "Select profile number (h for help): "
    read -r num
    [[ "$num" == "h" || "$num" == "H" ]] && { show_help_screen "Select a profile number to load."; load_profile; return; }
    if [[ "$num" =~ ^[0-9]+$ && $num -ge 1 && $num -le ${#profiles[@]} ]]; then
        local selected="${profiles[$((num-1))]}"
        cp "$PROFILES_DIR/${selected}.toml" "$CONFIG_FILE"
        [[ -f "$PROFILES_DIR/${selected}.resolvers.txt" ]] && cp "$PROFILES_DIR/${selected}.resolvers.txt" "$RESOLVERS_FILE"
        printf "\n"$MSG_LOADED"\n"
    elif [[ $num -eq $(( ${#profiles[@]} + 1 )) ]]; then
        :
    else
        printf "\n"$ERR_INVALID_NUMBER"\n"
    fi
    press_enter
}

delete_profile() {
    clear_screen; printf "%b\n\n" "$DELETE_PROFILE_HEADER"
    local profiles=($(list_profiles))
    [[ ${#profiles[@]} -eq 0 ]] && { printf "%b\n" "$ERR_NO_PROFILES"; press_enter; return; }
    for i in "${!profiles[@]}"; do printf "  %d. %s\n" $((i+1)) "${profiles[$i]}"; done
    printf "  %d. Back\n\nDelete:\n> " $(( ${#profiles[@]} + 1 ))
    read -r num
    [[ "$num" == "h" ]] && { show_help_screen "Select a profile to delete."; delete_profile; return; }
    if [[ "$num" =~ ^[0-9]+$ && $num -ge 1 && $num -le ${#profiles[@]} ]]; then
        local selected="${profiles[$((num-1))]}"
        rm -f "$PROFILES_DIR/${selected}.toml" "$PROFILES_DIR/${selected}.resolvers.txt" 2>/dev/null
        printf "\n"$MSG_DELETED"\n"
    elif [[ $num -eq $(( ${#profiles[@]} + 1 )) ]]; then
        :
    else
        printf "\n"$ERR_INVALID_NUMBER"\n"
    fi
    press_enter
}

profile_menu() {
    while true; do
        clear_screen; printf "%b" "$PROFILE_MENU"
        read -rsn1 c
        case "$c" in
            1) printf "\n"; create_profile ;;
            2) printf "\n"; load_profile ;;
            3) printf "\n"; delete_profile ;;
            4) return ;;
            h|H) printf "\n"; show_help_screen "Profile Menu: Create, Load, Delete profiles." ;;
            *) printf "\n%b\n" "$ERR_INVALID_CHOICE"; press_enter ;;
        esac
    done
}

#######################################
# 6. MTU Speed Test
#######################################

get_test_valid()   { grep -E 'valid=[0-9]+' "$MTU_TEST_DIR/test/client.log" 2>/dev/null | tail -1 | sed -n 's/.*valid=\([0-9]\+\).*/\1/p' || echo 0; }
get_test_rejected(){ grep -E 'rejected=[0-9]+' "$MTU_TEST_DIR/test/client.log" 2>/dev/null | tail -1 | sed -n 's/.*rejected=\([0-9]\+\).*/\1/p' || echo 0; }
get_test_active()  {
    local v=$(grep -E 'Total Active:|Remaining:' "$MTU_TEST_DIR/test/client.log" 2>/dev/null | tail -1 | sed -n 's/.*\(Total Active\|Remaining\): *\([0-9]\+\).*/\2/p')
    [[ -z "$v" ]] && v=$(get_test_valid)
    echo "$v"
}
get_test_stream()  { grep 'Stream ID:' "$MTU_TEST_DIR/test/client.log" 2>/dev/null | tail -1 | sed -n 's/.*Stream ID: *\([0-9]\+\).*/\1/p' || echo 0; }
test_proxy_ready() { grep -q 'SOCKS5 Proxy server is listening' "$MTU_TEST_DIR/test/client.log" 2>/dev/null && echo "yes" || echo "no"; }

start_mtu_speed_test() {
    [[ ! -f "$CLIENT_BIN" ]] && { printf "%b\n" "$ERR_BINARY_NOT_FOUND"; press_enter; return; }
    [[ ! -f "$CONFIG_FILE" ]] && { printf "%b\n" "$ERR_NO_CONFIG"; press_enter; return; }
    [[ ! -f "$RESOLVERS_FILE" || ! -s "$RESOLVERS_FILE" ]] && { printf "%b\n" "$ERR_NO_RESOLVERS"; press_enter; return; }
    command -v curl &>/dev/null || { printf "%b\n" "$ERR_NEED_CURL"; press_enter; return; }

    clear_screen; printf "%b\n\n" "$MTU_INFO_BOX"; printf "%b\n\n" "$MTU_INFO_TEXT"
    printf "%b" "$MTU_START_PROMPT"
    read -rsn1 c
    case "$c" in
        y|Y) ;;
        h|H) show_help_screen "$MTU_INTRO_HELP"; start_mtu_speed_test; return ;;
        *) return ;;
    esac

    kill_all_clients
    PORTS=(18001 18002 18003 18004 18005 18006)
    MIN_UP=(30 50 70 90 110 130); MAX_UP=(50 70 90 110 130 150)
    MIN_DOWN=(60 260 460 660 860 1060); MAX_DOWN=(300 500 700 900 1100 1300)
    declare -A total_bytes final_valid final_rejected
    for i in 1 2 3 4 5 6; do total_bytes[$i]=0; final_valid[$i]=0; final_rejected[$i]=0; done
    abort_all=0

    for i in 1 2 3 4 5 6; do
        [[ $abort_all -eq 1 ]] && break
        idx=$((i-1)); port=${PORTS[$idx]}
        rm -rf "$MTU_TEST_DIR"; mkdir -p "$MTU_TEST_DIR/test"
        cp "$CLIENT_BIN" "$MTU_TEST_DIR/test/"
        cp "$CONFIG_FILE" "$MTU_TEST_DIR/test/client_config.toml"
        cp "$RESOLVERS_FILE" "$MTU_TEST_DIR/test/client_resolvers.txt"
        sed -i "s|^LISTEN_PORT = .*|LISTEN_PORT = $port|" "$MTU_TEST_DIR/test/client_config.toml"
        sed -i "s|^MIN_UPLOAD_MTU = .*|MIN_UPLOAD_MTU = ${MIN_UP[$idx]}|" "$MTU_TEST_DIR/test/client_config.toml"
        sed -i "s|^MAX_UPLOAD_MTU = .*|MAX_UPLOAD_MTU = ${MAX_UP[$idx]}|" "$MTU_TEST_DIR/test/client_config.toml"
        sed -i "s|^MIN_DOWNLOAD_MTU = .*|MIN_DOWNLOAD_MTU = ${MIN_DOWN[$idx]}|" "$MTU_TEST_DIR/test/client_config.toml"
        sed -i "s|^MAX_DOWNLOAD_MTU = .*|MAX_DOWNLOAD_MTU = ${MAX_DOWN[$idx]}|" "$MTU_TEST_DIR/test/client_config.toml"

        cd "$MTU_TEST_DIR/test"
        chmod +x "$CLIENT_BIN" 2>/dev/null || true
        nohup "$CLIENT_BIN" -config "./client_config.toml" < /dev/null >> "./client.log" 2>&1 & tp=$!
        cd "$MASTER_DNS_DIR"

        proxy_ok=0 bytes=0 skipped=0 dl_start=0 dl_timeout=90 curl_pid=""
        while true; do
            clear_screen; print_mtu_step_box "$i"
            printf "\n${WHITE}Port %d: UP[%d–%d] DOWN[%d–%d]${NC}\n\n" "$port" "${MIN_UP[$idx]}" "${MAX_UP[$idx]}" "${MIN_DOWN[$idx]}" "${MAX_DOWN[$idx]}"
            v=$(get_test_valid); r=$(get_test_rejected); a=$(get_test_active); s=$(get_test_stream); pr=$(test_proxy_ready)
            ps="${RED}Waiting…${NC}"; [[ "$pr" == "yes" ]] && ps="${GREEN}Ready ✓${NC}"
            printf "Resolvers: ${GREEN}%s${NC}/${RED}%s${NC} | Active: ${CYAN}%s${NC} | Streams: ${CYAN}%s${NC} | Proxy: %b\n" "$v" "$r" "$a" "$s" "$ps"
            if [[ $proxy_ok -eq 1 ]]; then
                now=$(date +%s); el=$((now - dl_start)); rem=$((dl_timeout - el)); [[ $rem -lt 0 ]] && rem=0
                sz=$(wc -c < "$MTU_TEST_DIR/test/download.tmp" 2>/dev/null || echo 0)
                printf "Download: ${GREEN}%d${NC} bytes | Time: %ds/%ds\n" "$sz" "$el" "$dl_timeout"
                if [[ $el -ge $dl_timeout ]]; then proxy_ok=2; break; fi
                if ! kill -0 "$curl_pid" 2>/dev/null; then proxy_ok=2; break; fi
            fi
            printf "\n${YELLOW}[L] View Log  [S] Skip  [Q] Abort${NC}\n> "
            read -rsn1 -t 1 key
            case "$key" in
                l|L)
                    clear_screen; printf "── Test Log (Q to exit) ──\n\n"
                    if [[ -f "$MTU_TEST_DIR/test/client.log" ]]; then
                        tail -n 50 -f "$MTU_TEST_DIR/test/client.log" 2>/dev/null & ltp=$!
                        while true; do
                            read -s -n 1 -t 0.5 lkey 2>/dev/null
                            [[ $? -eq 0 ]] || continue
                            if [[ "$lkey" == "q" || "$lkey" == "Q" ]]; then
                                kill "$ltp" 2>/dev/null
                                break
                            fi
                        done
                        wait "$ltp" 2>/dev/null
                    else printf "No log.\n"; press_enter; fi
                    ;;
                s|S) skipped=1; break ;;
                q|Q) abort_all=1; break ;;
            esac
            [[ $proxy_ok -eq 0 && "$(test_proxy_ready)" == "yes" ]] && {
                proxy_ok=1; dl_start=$(date +%s)
                rm -f "$MTU_TEST_DIR/test/download.tmp"
                curl -x "socks5h://127.0.0.1:$port" -o "$MTU_TEST_DIR/test/download.tmp" -s --max-time "$dl_timeout" \
                    "https://speed.cloudflare.com/__down?bytes=2097152" 2>/dev/null & curl_pid=$!
            }
        done
        [[ $abort_all -eq 1 ]] && break
        if [[ $proxy_ok -eq 2 ]]; then
            wait "$curl_pid" 2>/dev/null || true
            actual_size=$(wc -c < "$MTU_TEST_DIR/test/download.tmp" 2>/dev/null || echo 0)
            [[ $actual_size -ge 2097152 ]] && bytes=2097152 || bytes=$actual_size
        fi
        final_valid[$i]=$(get_test_valid); final_rejected[$i]=$(get_test_rejected); total_bytes[$i]=$bytes
        kill "$tp" 2>/dev/null; sleep 1; kill -9 "$tp" 2>/dev/null
        rm -rf "$MTU_TEST_DIR"
        [[ $abort_all -eq 1 ]] && break
    done

    clear_screen; printf "%b\n\n" "$MTU_RESULTS_HEADER"
    printf "${WHITE}Port    UP MTU       DOWN MTU      Resolvers      Downloaded${NC}\n"
    printf "──────────────────────────────────────────────────────────\n"
    best_step=0; best_bytes=0
    for i in 1 2 3 4 5 6; do
        idx=$((i-1)); tb=${total_bytes[$i]}; v=${final_valid[$i]}; r=${final_rejected[$i]}
        printf "  %-5d  %-11s  %-12s  ${GREEN}%-4s${NC}/${RED}%-4s${NC}  ${GREEN}%d bytes${NC}\n" \
            "${PORTS[$idx]}" "${MIN_UP[$idx]}-${MAX_UP[$idx]}" "${MIN_DOWN[$idx]}-${MAX_DOWN[$idx]}" "$v" "$r" "$tb"
        [[ $tb -gt $best_bytes ]] && { best_bytes=$tb; best_step=$i; }
    done
    [[ $best_step -gt 0 ]] && {
        bi=$((best_step-1))
        printf "\n"$MTU_BEST_MSG"\n" "${PORTS[$bi]}" "${MIN_UP[$bi]}" "${MAX_UP[$bi]}" "${MIN_DOWN[$bi]}" "${MAX_DOWN[$bi]}" "$best_bytes"
    }
    press_enter
}

#######################################
# 7. Resolver Health Check
#######################################

start_resolver_health_check() {
    clear_screen; printf "%b\n\n" "$HEALTH_INFO_BOX"; printf "%b\n\n" "$HEALTH_INFO_TEXT"
    printf "${YELLOW}Press h for help at any prompt.${NC}\n\n"
    command -v curl &>/dev/null || { printf "%b\n" "$ERR_NEED_CURL"; press_enter; return; }

    if ! is_running; then printf "%b\n" "$ERR_CLIENT_NOT_RUNNING"; press_enter; return; fi

    if [[ "$(proxy_ready)" != "yes" ]]; then
        local wait_count=0
        while [[ "$(proxy_ready)" != "yes" && $wait_count -lt 60 ]]; do
            clear_screen
            printf "%b\n\n" "$HEALTH_INFO_BOX"
            printf "%b\n\n" "$HEALTH_INFO_TEXT"
            printf "${YELLOW}Press h for help at any prompt.${NC}\n\n"
            printf "%b\n" "$INFO_PROXY_WAITING"
            printf "${YELLOW}[B] Back to menu${NC}\n"
            printf "\nWaiting %ds...\n" $wait_count
            read -rsn1 -t 1 key 2>/dev/null
            if [[ "$key" == "b" || "$key" == "B" ]]; then
                printf "\n${YELLOW}Returning to menu.${NC}\n"
                press_enter; return
            fi
            sleep 1
            ((wait_count++))
        done
        if [[ "$(proxy_ready)" != "yes" ]]; then
            printf "%b\n" "$ERR_PROXY_NOT_READY"
            press_enter; return
        fi
        printf "%b\n" "$INFO_PROXY_READY_NOW"
    fi

    printf "${WHITE}Select test type:${NC}\n  1. Cloudflare download\n  2. Telegram ping\n  3. Back\nChoose [1-3, h]: "
    read -rsn1 test_type
    case "$test_type" in
        h|H) show_help_screen "$HEALTH_INTRO_HELP"; start_resolver_health_check; return ;;
        1) ;;
        2) ;;
        3) return ;;
        *) printf "\n%b\n" "$ERR_INVALID_CHOICE"; press_enter; return ;;
    esac

    local file_size_kb=0 file_size_bytes=0
    if [[ "$test_type" == "1" ]]; then
        printf "\n${WHITE}File size in KB (e.g. 100):${NC}\n> "
        read -r file_size_kb
        [[ "$file_size_kb" == "h" ]] && { show_help_screen "Size between 10 and 10240 KB."; start_resolver_health_check; return; }
        [[ ! "$file_size_kb" =~ ^[0-9]+$ || $file_size_kb -lt 10 ]] && { printf "${RED}Invalid.${NC}\n"; press_enter; return; }
        file_size_bytes=$(( file_size_kb * 1024 ))
    fi

    printf "${WHITE}Timeout in seconds (e.g. 10):${NC}\n> "
    read -r req_timeout
    [[ "$req_timeout" == "h" ]] && { show_help_screen "Request timeout."; start_resolver_health_check; return; }
    [[ ! "$req_timeout" =~ ^[0-9]+$ || $req_timeout -lt 1 ]] && { printf "${RED}Invalid.${NC}\n"; press_enter; return; }

    printf "${WHITE}Interval between requests in seconds (e.g. 0.5):${NC}\n> "
    read -r interval_sec
    [[ "$interval_sec" == "h" ]] && { show_help_screen "Delay between requests in seconds (>= 0.2)."; start_resolver_health_check; return; }
    if [[ ! "$interval_sec" =~ ^[0-9.]+$ ]] || (( $(echo "$interval_sec < 0.2" | bc -l 2>/dev/null || echo 0) )); then
        printf "${RED}Invalid (minimum 0.2).${NC}\n"; press_enter; return
    fi

    local tmpdir="${TMPDIR:-/tmp}/mdv_health_$$"; rm -rf "$tmpdir"; mkdir -p "$tmpdir"
    local launched_file="$tmpdir/launched" stop_file="$tmpdir/stop"
    echo 0 > "$launched_file"; echo 0 > "$stop_file"
    local MAX_CONCURRENT=10
    count_running() { pgrep -f 'curl.*(__down|149\.154\.167\.92)' 2>/dev/null | wc -l; }

    (
        while [[ $(<"$stop_file") -eq 0 ]]; do
            running=$(count_running)
            if [[ $running -lt $MAX_CONCURRENT ]]; then
                idx=$( ( flock -x 200; read -r num < "$launched_file"; echo $((num+1)) > "$launched_file"; echo $num ) 200>"$tmpdir/lock" )
                ts=$(date +%s.%N 2>/dev/null || date +%s)
                (
                    if [[ "$test_type" == "1" ]]; then
                        output=$(curl -x "socks5h://127.0.0.1:18000" -o /dev/null -s -w "%{http_code} %{size_download} %{time_total}" --connect-timeout "$req_timeout" --max-time "$req_timeout" "https://speed.cloudflare.com/__down?bytes=$file_size_bytes" 2>/dev/null)
                        http_code=$(echo "$output" | awk '{print $1}')
                        size=$(echo "$output" | awk '{print $2}')
                        latency=$(echo "$output" | awk '{print $3}')
                        echo "$idx $ts $http_code $latency $size" > "$tmpdir/result_$idx.tmp" 2>/dev/null
                    else
                        output=$(curl -x "socks5h://127.0.0.1:18000" -o /dev/null -s -w "%{http_code} %{time_total}" --connect-timeout "$req_timeout" --max-time "$req_timeout" -k "https://149.154.167.92:443" 2>/dev/null)
                        http_code=$(echo "$output" | awk '{print $1}')
                        latency=$(echo "$output" | awk '{print $2}')
                        if [[ -n "$http_code" && "$http_code" =~ ^[0-9]+$ && "$latency" =~ ^[0-9.]+$ ]]; then
                            if awk -v lt="$latency" -v rt="$req_timeout" 'BEGIN{exit !(lt < rt)}'; then
                                echo "$idx $ts $http_code $latency 0" > "$tmpdir/result_$idx.tmp"
                            else
                                echo "$idx $ts 000 $latency 0" > "$tmpdir/result_$idx.tmp"
                            fi
                        else
                            echo "$idx $ts 000 $latency 0" > "$tmpdir/result_$idx.tmp"
                        fi
                    fi
                    mv "$tmpdir/result_$idx.tmp" "$tmpdir/result_$idx" 2>/dev/null
                ) &
            fi
            sleep "$interval_sec" 2>/dev/null || sleep 0.2
        done
    ) & fire_pid=$!

    LAST_KNOWN_ACTIVE=$(get_active)
    get_live_active_display() {
        local v=$(grep -E 'Total Active:|Remaining:|Active resolvers:' "$LOG_FILE" 2>/dev/null | tail -1 | sed -n 's/.*\(Total Active\|Remaining\|Active resolvers\): *\([0-9]\+\).*/\2/p')
        if [[ -n "$v" ]]; then
            LAST_KNOWN_ACTIVE="$v"
            echo "$v"
        else
            echo "$LAST_KNOWN_ACTIVE"
        fi
    }

    local initial_active=$(get_live_active_display) success=0 failed=0 total_latency=0 processed=0 start_time=$(date +%s)
    local last_active=$initial_active

    clear_screen; printf "%b\n\n" "$HEALTH_RUNNING_BOX"
    printf "Test: ${CYAN}%s${NC}\n" "$([[ "$test_type" == "1" ]] && echo "Cloudflare ${file_size_kb}KB" || echo "Telegram ping")"
    printf "Timeout: ${CYAN}%ss${NC}   Interval: ${CYAN}%s s${NC}\n\n" "$req_timeout" "$interval_sec"
    printf "[Q] Stop  [B] Finish\n\n"
    printf "%-6s %-10s %-4s | %-10s\n" "Req#" "Time" "OK?" "Active Rsolv"
    printf "─────────────────────────────────────\n"

    while true; do
        read -rsn1 -t 0.1 key; [[ "$key" == "q" || "$key" == "Q" ]] && { echo 1 > "$stop_file"; break; }
        [[ "$key" == "b" || "$key" == "B" ]] && { echo 1 > "$stop_file"; break; }
        local files=("$tmpdir"/result_*)
        if [[ -f "${files[0]}" ]]; then
            for f in "${files[@]}"; do
                [[ -f "$f" ]] || continue
                local idx ts http_code latency size; read -r idx ts http_code latency size < "$f"; rm -f "$f"
                ((processed++))
                local current_active=$(get_live_active_display)
                local active_change="${CYAN}=${current_active}${NC}"
                [[ $current_active -lt $last_active ]] && active_change="${RED}↓${current_active}${NC}"
                [[ $current_active -gt $last_active ]] && active_change="${GREEN}↑${current_active}${NC}"
                last_active=$current_active
                local ok_flag=0
                if [[ "$test_type" == "1" ]]; then
                    [[ "$http_code" == "200" && $size -ge $file_size_bytes ]] && ok_flag=1
                else
                    [[ -n "$http_code" && "$http_code" =~ ^[0-9]+$ && "$latency" =~ ^[0-9.]+$ ]] && awk -v lt="$latency" -v rt="$req_timeout" 'BEGIN{exit !(lt < rt)}' && ok_flag=1
                fi
                if [[ $ok_flag -eq 1 ]]; then
                    printf "${GREEN}%-6s %-10s YES${NC} | %b\n" "$idx" "${latency}s" "$active_change"
                    ((success++)); total_latency=$(awk "BEGIN {printf \"%.3f\", $total_latency + $latency}" 2>/dev/null)
                else
                    printf "${RED}%-6s %-10s NO${NC}  | %b\n" "$idx" "${latency}s" "$active_change"
                    ((failed++))
                fi
            done
        fi
        if [[ $(<"$stop_file") -eq 1 ]]; then
            if ! ls "$tmpdir"/result_* &>/dev/null && ! kill -0 "$fire_pid" 2>/dev/null; then
                break
            fi
        fi
        sleep 0.2
    done

    echo 1 > "$stop_file"; kill "$fire_pid" 2>/dev/null; wait "$fire_pid" 2>/dev/null; sleep 0.5
    pkill -f 'curl.*(__down|149\.154\.167\.92)' 2>/dev/null; sleep 0.3
    for f in "$tmpdir"/result_*; do
        [[ -f "$f" ]] || continue
        local idx ts http_code latency size; read -r idx ts http_code latency size < "$f"; rm -f "$f"; ((processed++))
        local ok_flag=0
        if [[ "$test_type" == "1" ]]; then
            [[ "$http_code" == "200" && $size -ge $file_size_bytes ]] && ok_flag=1
        else
            [[ -n "$http_code" && "$http_code" =~ ^[0-9]+$ && "$latency" =~ ^[0-9.]+$ ]] && awk -v lt="$latency" -v rt="$req_timeout" 'BEGIN{exit !(lt < rt)}' && ok_flag=1
        fi
        if [[ $ok_flag -eq 1 ]]; then ((success++)); total_latency=$(awk "BEGIN {printf \"%.3f\", $total_latency + $latency}" 2>/dev/null); else ((failed++)); fi
    done
    rm -rf "$tmpdir"

    local end_time=$(date +%s) total_time=$((end_time - start_time))
    [[ $total_time -lt 1 ]] && total_time=1
    local final_active=$(get_live_active_display)

    clear_screen; printf "\n%b\n\n" "$HEALTH_SUMMARY_HEADER"
    printf "Test type:       ${CYAN}%s${NC}\n" "$([[ "$test_type" == "1" ]] && echo "Cloudflare ${file_size_kb}KB" || echo "Telegram ping")"
    printf "Total:           ${CYAN}%d${NC}\n" "$processed"
    printf "Successful:      ${GREEN}%d${NC}\n" "$success"
    printf "Failed:          ${RED}%d${NC}\n" "$failed"
    printf "Duration:        ${CYAN}%d s${NC}\n" "$total_time"
    printf "Avg rate:        ${CYAN}%.1f req/s${NC}\n" "$(awk "BEGIN {printf \"%.1f\", $processed / $total_time}")"
    [[ $success -gt 0 ]] && printf "Avg time (OK):   ${CYAN}%s ms${NC}\n" "$(awk "BEGIN {printf \"%.0f\", $total_latency / $success * 1000}")"
    printf "Active (start):  ${CYAN}%s${NC}\n" "$initial_active"
    printf "Active (end):    ${CYAN}%s${NC}\n" "$final_active"
    local diff=$(( initial_active - final_active ))
    if [[ $diff -gt 0 ]]; then printf "Removed:         ${RED}%d${NC}\n" "$diff"
    elif [[ $diff -lt 0 ]]; then printf "Added:           ${GREEN}%d${NC}\n" $(( -diff ))
    else printf "Removed:         0\n"; fi
    press_enter
}

#######################################
# 8. Multi‑Connection
#######################################

show_proxy_lists() {
    local count=$1 base_port=$2
    printf "%b\n" ""
    printf "%b\n" "${CYAN}══════════════════════════════════════════════════════════════${NC}"
    printf "%b\n" "${GREEN}Add these proxies to Telegram (Settings → Advanced → Connection Type):${NC}"
    for ((i=0; i<count; i++)); do
        local port=$((base_port + i))
        printf "%b\n" "${WHITE}${i}. https://t.me/socks?server=127.0.0.1&port=${port}${NC}"
    done
    printf "%b\n" ""
    printf "%b\n" "${GREEN}Add these configs to Hiddify (Copy and paste):${NC}"
    for ((i=0; i<count; i++)); do
        local port=$((base_port + i))
        printf "%b\n" "${WHITE}socks://Og@127.0.0.1:${port}#${port}${NC}"
    done
    printf "%b\n" "${CYAN}══════════════════════════════════════════════════════════════${NC}"
    printf "%b\n" ""
}

get_multi_valid()   { grep -E 'valid=[0-9]+' "$MULTI_DIR/$1/client.log" 2>/dev/null | tail -1 | sed -n 's/.*valid=\([0-9]\+\).*/\1/p' || echo 0; }
get_multi_rejected(){ grep -E 'rejected=[0-9]+' "$MULTI_DIR/$1/client.log" 2>/dev/null | tail -1 | sed -n 's/.*rejected=\([0-9]\+\).*/\1/p' || echo 0; }
get_multi_active()  {
    local v=$(grep -E 'Total Active:|Remaining:' "$MULTI_DIR/$1/client.log" 2>/dev/null | tail -1 | sed -n 's/.*\(Total Active\|Remaining\): *\([0-9]\+\).*/\2/p')
    [[ -z "$v" ]] && v=$(get_multi_valid "$1")
    echo "$v"
}
get_multi_stream()  { grep 'Stream ID:' "$MULTI_DIR/$1/client.log" 2>/dev/null | tail -1 | sed -n 's/.*Stream ID: *\([0-9]\+\).*/\1/p' || echo 0; }
multi_proxy_ready() { grep -q 'SOCKS5 Proxy server is listening' "$MULTI_DIR/$1/client.log" 2>/dev/null && echo "yes" || echo "no"; }

show_multi_dashboard() {
    local pids=("$@") count=${#pids[@]}
    trap 'echo ""; for pid in "${pids[@]}"; do kill "$pid" 2>/dev/null || true; done; show_cursor; exit 0' INT
    while true; do
        clear_screen; printf "%b\n\n" "$MULTI_DASHBOARD_HEADER"
        print_multi_col_headers
        printf "──────────────────────────────────────────────────────────────\n"
        for i in $(seq 1 $count); do
            local dir="$MULTI_DIR/$i"
            local port=$(cat "$dir/port.txt" 2>/dev/null || echo "?")
            local pname=$(cat "$dir/profile_name.txt" 2>/dev/null || echo "unknown")
            local v=$(get_multi_valid "$i"); local r=$(get_multi_rejected "$i")
            local a=$(get_multi_active "$i"); local s=$(get_multi_stream "$i")
            local pr=$(multi_proxy_ready "$i")
            local ps="${RED}✗${NC}"; [[ "$pr" == "yes" ]] && ps="${GREEN}✓${NC}"
            printf "%-2d %-6s %-28s ${GREEN}%8s${NC} ${RED}%8s${NC} ${CYAN}%8s${NC} ${CYAN}%8s${NC} %6b\n" \
                   "$i" "$port" "$pname" "$v" "$r" "$a" "$s" "$ps"
        done
        printf "\n%b\n> " "$MULTI_DASHBOARD_KEYS"
        read -rsn1 -t 2 ch
        case "$ch" in
            v|V) printf "\nLog of instance [1-%d]: " "$count"; read -r ln
                if [[ "$ln" =~ ^[0-9]+$ && $ln -ge 1 && $ln -le $count ]]; then
                    clear_screen; local pname=$(cat "$MULTI_DIR/$ln/profile_name.txt" 2>/dev/null)
                    printf "── Log #%d (%s) (Q to exit) ──\n\n" "$ln" "$pname"
                    if [[ -f "$MULTI_DIR/$ln/client.log" ]]; then
                        tail -n 50 -f "$MULTI_DIR/$ln/client.log" 2>/dev/null & tp=$!
                        while true; do
                            read -s -n 1 -t 0.5 lkey 2>/dev/null
                            [[ $? -eq 0 ]] || continue
                            if [[ "$lkey" == "q" || "$lkey" == "Q" ]]; then
                                kill "$tp" 2>/dev/null
                                break
                            fi
                        done
                        wait "$tp" 2>/dev/null
                    else printf "No log.\n"; press_enter; fi
                fi ;;
            s|S) printf "\n%b\n" "$MSG_STOPPING_ALL"; for pid in "${pids[@]}"; do kill "$pid" 2>/dev/null; done; sleep 2; for pid in "${pids[@]}"; do kill -9 "$pid" 2>/dev/null; done; printf "%b\n" "$MSG_ALL_STOPPED"; sleep 1; return ;;
            q|Q) return ;;
        esac
    done
}

start_multi_profiles() {
    [[ ! -f "$CLIENT_BIN" ]] && { printf "%b\n" "$ERR_BINARY_NOT_FOUND"; press_enter; return; }
    [[ ! -f "$CONFIG_FILE" ]] && { printf "%b\n" "$ERR_NO_CONFIG"; press_enter; return; }
    local domain=$(get_domain_from_config) key=$(get_key_from_config)
    [[ -z "$domain" || -z "$key" ]] && { printf "%b\n" "$ERR_MISSING_DOMAIN_KEY"; press_enter; return; }

    clear_screen; printf "%b\n\n" "$MULTI_PROFILE_SELECT_HEADER"
    printf "${WHITE}Available profiles:${NC}\n\n%s\n\n" "$MULTI_PROFILE_LIST"
    printf "%b" "$MULTI_RUN_ALL"; read -r run_all
    local selected_indices=()
    if [[ "$run_all" == "y" || "$run_all" == "Y" ]]; then
        for i in 0 1 2 3 4 5 6 7; do selected_indices+=($i); done
    else
        printf "\n%b\n> " "$MULTI_SELECT_GUIDE"
        read -r user_selection; user_selection="${user_selection// /}"
        IFS=',' read -ra nums <<< "$user_selection"
        for num in "${nums[@]}"; do [[ "$num" =~ ^[0-7]$ ]] && selected_indices+=($num); done
        [[ ${#selected_indices[@]} -eq 0 ]] && { printf "\n%b\n" "$ERR_NO_VALID_SELECTION"; press_enter; return; }
    fi

    local instance_count=${#selected_indices[@]}
    show_proxy_lists $instance_count 18001
    printf "${YELLOW}Press ENTER to continue or Q to cancel…${NC}\n> "
    read -r confirm; [[ "$confirm" == "q" || "$confirm" == "Q" ]] && return
    printf "\n%b\n> " "$MULTI_CUSTOM_PAR"; read -r custom_par
    local apply_custom_par=0; [[ -n "$custom_par" && "$custom_par" =~ ^[0-9]+$ && $custom_par -gt 0 ]] && apply_custom_par=1

    kill_all_clients; rm -rf "$MULTI_DIR"; mkdir -p "$MULTI_DIR"
    local pids=() instance=1 base_port=18001
    for idx in "${selected_indices[@]}"; do
        local port=$((base_port + instance - 1))
        local template="${TEMPLATE_FILES_MAP[$idx]}" template_name="${TEMPLATE_NAMES_MAP[$idx]}"
        local dir="$MULTI_DIR/$instance"; mkdir -p "$dir"
        [[ ! -f "$template" ]] && { printf "${RED}Template %s missing.${NC}\n" "$template_name"; ((instance++)); continue; }

        cp "$CLIENT_BIN" "$dir/"; cp "$template" "$dir/client_config.toml"
        sanitize_toml "$dir/client_config.toml"
        [[ -f "$RESOLVERS_FILE" ]] && cp "$RESOLVERS_FILE" "$dir/client_resolvers.txt"
        sed -i "s|^DOMAINS = \[.*\]|DOMAINS = [\"$domain\"]|" "$dir/client_config.toml"
        sed -i "s|^ENCRYPTION_KEY = \".*\"|ENCRYPTION_KEY = \"$key\"|" "$dir/client_config.toml"
        sed -i "s|^LISTEN_PORT = .*|LISTEN_PORT = $port|" "$dir/client_config.toml"
        [[ $apply_custom_par -eq 1 ]] && sed -i "s|^MTU_TEST_PARALLELISM = .*|MTU_TEST_PARALLELISM = $custom_par|" "$dir/client_config.toml"
        echo "$port" > "$dir/port.txt"; echo "$template_name" > "$dir/profile_name.txt"
        cd "$dir"; chmod +x "$CLIENT_BIN" 2>/dev/null; nohup "$CLIENT_BIN" -config "./client_config.toml" < /dev/null >> "./client.log" 2>&1 &
        pids+=($!); cd "$MASTER_DNS_DIR"
        printf "  %b %s on port %d (PID %d)\n" "$MSG_STARTED" "$template_name" "$port" "${pids[-1]}"
        ((instance++))
    done
    [[ ${#pids[@]} -eq 0 ]] && { printf "\n${RED}Nothing started.${NC}\n"; press_enter; return; }
    press_enter "Dashboard opening..."; show_multi_dashboard "${pids[@]}"
}

start_multi_mtu() {
    [[ ! -f "$CLIENT_BIN" ]] && { printf "%b\n" "$ERR_BINARY_NOT_FOUND"; press_enter; return; }
    [[ ! -f "$CONFIG_FILE" ]] && { printf "%b\n" "$ERR_NO_CONFIG"; press_enter; return; }
    [[ ! -f "$RESOLVERS_FILE" || ! -s "$RESOLVERS_FILE" ]] && { printf "%b\n" "$ERR_NO_RESOLVERS"; press_enter; return; }
    show_proxy_lists 6 18001
    printf "${YELLOW}Press ENTER to continue or Q to cancel…${NC}\n> "
    read -r confirm; [[ "$confirm" == "q" || "$confirm" == "Q" ]] && return
    printf "\n%b\n> " "$MULTI_CUSTOM_PAR"; read -r custom_par
    local apply_custom_par=0; [[ -n "$custom_par" && "$custom_par" =~ ^[0-9]+$ && $custom_par -gt 0 ]] && apply_custom_par=1

    kill_all_clients; rm -rf "$MULTI_DIR"; mkdir -p "$MULTI_DIR"
    local pids=()
    local MIN_UP=(30 50 70 90 110 130) MAX_UP=(50 70 90 110 130 150)
    local MIN_DOWN=(60 260 460 660 860 1060) MAX_DOWN=(300 500 700 900 1100 1300)
    for i in 1 2 3 4 5 6; do
        local idx=$((i-1)) port=$((18000 + i)) dir="$MULTI_DIR/$i"; mkdir -p "$dir"
        cp "$CLIENT_BIN" "$dir/"; cp "$CONFIG_FILE" "$dir/client_config.toml"; cp "$RESOLVERS_FILE" "$dir/client_resolvers.txt"
        sanitize_toml "$dir/client_config.toml"
        sed -i "s|^LISTEN_PORT = .*|LISTEN_PORT = $port|" "$dir/client_config.toml"
        sed -i "s|^MIN_UPLOAD_MTU = .*|MIN_UPLOAD_MTU = ${MIN_UP[$idx]}|" "$dir/client_config.toml"
        sed -i "s|^MAX_UPLOAD_MTU = .*|MAX_UPLOAD_MTU = ${MAX_UP[$idx]}|" "$dir/client_config.toml"
        sed -i "s|^MIN_DOWNLOAD_MTU = .*|MIN_DOWNLOAD_MTU = ${MIN_DOWN[$idx]}|" "$dir/client_config.toml"
        sed -i "s|^MAX_DOWNLOAD_MTU = .*|MAX_DOWNLOAD_MTU = ${MAX_DOWN[$idx]}|" "$dir/client_config.toml"
        [[ $apply_custom_par -eq 1 ]] && sed -i "s|^MTU_TEST_PARALLELISM = .*|MTU_TEST_PARALLELISM = $custom_par|" "$dir/client_config.toml"
        echo "$port" > "$dir/port.txt"; echo "MTU-${MIN_UP[$idx]}-${MAX_UP[$idx]}" > "$dir/profile_name.txt"
        cd "$dir"; chmod +x "$CLIENT_BIN" 2>/dev/null; nohup "$CLIENT_BIN" -config "./client_config.toml" < /dev/null >> "./client.log" 2>&1 &
        pids+=($!); cd "$MASTER_DNS_DIR"
    done
    press_enter "Dashboard opening..."; show_multi_dashboard "${pids[@]}"
}

multi_connection_menu() {
    while true; do
        clear_screen; printf "%b" "$MULTI_MENU"
        read -rsn1 c
        case "$c" in
            1) printf "\n"; start_multi_profiles ;;
            2) printf "\n"; start_multi_mtu ;;
            3) return ;;
            h|H) printf "\n"; show_help_screen "$MULTI_INTRO_HELP" ;;
            *) printf "\n%b\n" "$ERR_INVALID_CHOICE"; press_enter ;;
        esac
    done
}

#######################################
# 9. Resolver Management
#######################################

list_resolver_lists() {
    ls "$RESOLVER_LISTS_DIR" 2>/dev/null | grep '\.txt$' | sed 's/\.txt$//' || true
}

switch_resolver_list() {
    clear_screen; printf "%b\n\n" "$RESOLVER_SELECT_HEADER"
    local lists=($(list_resolver_lists))
    if [[ ${#lists[@]} -eq 0 ]]; then
        printf "%b\n" "$RESOLVER_NO_LISTS"; press_enter; return
    fi
    printf "Available lists:\n\n"
    for i in "${!lists[@]}"; do printf "  %d. %s\n" $((i+1)) "${lists[$i]}"; done
    printf "  %d. Back\n\nSelect: " $(( ${#lists[@]} + 1 ))
    read -r num
    if [[ "$num" =~ ^[0-9]+$ && $num -ge 1 && $num -le ${#lists[@]} ]]; then
        local selected="${lists[$((num-1))]}"
        cp "$RESOLVER_LISTS_DIR/${selected}.txt" "$RESOLVERS_FILE"
        printf "\n${GREEN}Switched to resolver list: %s${NC}\n" "$selected"
        auto_parallelism_enabled && update_all_configs_parallelism >/dev/null
    elif [[ $num -eq $(( ${#lists[@]} + 1 )) ]]; then
        :
    else
        printf "\n"$ERR_INVALID_NUMBER"\n"
    fi
    press_enter
}

import_resolver_list() {
    clear_screen; printf "%b\n\n" "${CYAN}══ Import Resolver List ══${NC}"
    printf "%b\n" "$RESOLVER_ADD_NAME"
    read -r list_name
    [[ -z "$list_name" ]] && { printf "%b\n" "$ERR_REQUIRED"; press_enter; return; }

    while true; do
        clear_screen
        printf "%b\n" "$RESOLVER_IMPORT_MENU"
        printf "Choose [1-3]: "
        read -rsn1 import_choice
        case "$import_choice" in
            1)
                printf "\n%b\n" "$RESOLVER_ADD_SOURCE"
                cat > "$RESOLVER_LISTS_DIR/${list_name}.txt"
                printf "\n${GREEN}List saved.${NC}\n"
                break
                ;;
            2)
                if ! command -v termux-dialog &>/dev/null; then
                    printf "\n%b\n" "$RESOLVER_TERMUXAPI_MISSING"
                    press_enter
                    continue
                fi
                local picked_file=$(termux-dialog -t file -d "*.txt" 2>/dev/null)
                if [[ -n "$picked_file" && -f "$picked_file" ]]; then
                    cp "$picked_file" "$RESOLVER_LISTS_DIR/${list_name}.txt"
                    printf "\n$RESOLVER_FILE_COPIED\n"
                else
                    printf "\n${YELLOW}No file selected.${NC}\n"
                fi
                break
                ;;
            3) return ;;
            *) printf "\n%b\n" "$ERR_INVALID_CHOICE"; press_enter ;;
        esac
    done
    press_enter
}

delete_resolver_list() {
    clear_screen; printf "%b\n\n" "${CYAN}══ Delete Resolver List ══${NC}"
    local lists=($(list_resolver_lists))
    if [[ ${#lists[@]} -eq 0 ]]; then
        printf "%b\n" "$RESOLVER_NO_LISTS"; press_enter; return
    fi
    for i in "${!lists[@]}"; do printf "  %d. %s\n" $((i+1)) "${lists[$i]}"; done
    printf "  %d. Back\n\nDelete: " $(( ${#lists[@]} + 1 ))
    read -r num
    if [[ "$num" =~ ^[0-9]+$ && $num -ge 1 && $num -le ${#lists[@]} ]]; then
        local selected="${lists[$((num-1))]}"
        rm -f "$RESOLVER_LISTS_DIR/${selected}.txt"
        printf "\n$RESOLVER_DELETED\n"
    elif [[ $num -eq $(( ${#lists[@]} + 1 )) ]]; then
        :
    else
        printf "\n"$ERR_INVALID_NUMBER"\n"
    fi
    press_enter
}

resolver_scanner() {
    [[ ! -f "$CLIENT_BIN" ]] && { printf "%b\n" "$ERR_BINARY_NOT_FOUND"; press_enter; return; }
    if ! has_valid_config; then
        printf "\n${RED}A valid profile with domain/key is required.${NC}\n"
        press_enter; return
    fi
    [[ ! -f "$RESOLVERS_FILE" || ! -s "$RESOLVERS_FILE" ]] && {
        printf "%b\n" "$ERR_NO_RESOLVERS"
        press_enter; return
    }

    show_help_screen "$SCANNER_INTRO_HELP"

    local domain=$(get_domain_from_config)
    local key=$(get_key_from_config)

    rm -rf "$SCANNER_DIR"; mkdir -p "$SCANNER_DIR"
    cp "$CLIENT_BIN" "$SCANNER_DIR/"
    cp "$RESOLVERS_FILE" "$SCANNER_DIR/client_resolvers.txt"

    cp "$CONFIG_FILE" "$SCANNER_DIR/client_config.toml"
    sanitize_toml "$SCANNER_DIR/client_config.toml"
    sed -i "s|^DOMAINS = \[.*\]|DOMAINS = [\"$domain\"]|" "$SCANNER_DIR/client_config.toml"
    sed -i "s|^ENCRYPTION_KEY = \".*\"|ENCRYPTION_KEY = \"$key\"|" "$SCANNER_DIR/client_config.toml"
    sed -i "s|^LISTEN_PORT = .*|LISTEN_PORT = 18009|" "$SCANNER_DIR/client_config.toml"

    grep -q '^SAVE_MTU_SERVERS_TO_FILE' "$SCANNER_DIR/client_config.toml" 2>/dev/null &&
        sed -i "s|^SAVE_MTU_SERVERS_TO_FILE = .*|SAVE_MTU_SERVERS_TO_FILE = true|" "$SCANNER_DIR/client_config.toml" ||
        echo 'SAVE_MTU_SERVERS_TO_FILE = true' >> "$SCANNER_DIR/client_config.toml"

    grep -q '^MTU_SERVERS_FILE_NAME' "$SCANNER_DIR/client_config.toml" 2>/dev/null &&
        sed -i 's|^MTU_SERVERS_FILE_NAME = .*|MTU_SERVERS_FILE_NAME = "masterdnsvpn_success_test.txt"|' "$SCANNER_DIR/client_config.toml" ||
        echo 'MTU_SERVERS_FILE_NAME = "masterdnsvpn_success_test.txt"' >> "$SCANNER_DIR/client_config.toml"

    grep -q '^MTU_SERVERS_FILE_FORMAT' "$SCANNER_DIR/client_config.toml" 2>/dev/null &&
        sed -i 's|^MTU_SERVERS_FILE_FORMAT = .*|MTU_SERVERS_FILE_FORMAT = "{IP}"|' "$SCANNER_DIR/client_config.toml" ||
        echo 'MTU_SERVERS_FILE_FORMAT = "{IP}"' >> "$SCANNER_DIR/client_config.toml"

    grep -q '^MTU_USING_SECTION_SEPARATOR_TEXT' "$SCANNER_DIR/client_config.toml" 2>/dev/null &&
        sed -i 's|^MTU_USING_SECTION_SEPARATOR_TEXT = .*|MTU_USING_SECTION_SEPARATOR_TEXT = ""|' "$SCANNER_DIR/client_config.toml" ||
        echo 'MTU_USING_SECTION_SEPARATOR_TEXT = ""' >> "$SCANNER_DIR/client_config.toml"

    grep -q '^MTU_TEST_PARALLELISM' "$SCANNER_DIR/client_config.toml" 2>/dev/null &&
        sed -i 's|^MTU_TEST_PARALLELISM = .*|MTU_TEST_PARALLELISM = 200|' "$SCANNER_DIR/client_config.toml" ||
        echo 'MTU_TEST_PARALLELISM = 200' >> "$SCANNER_DIR/client_config.toml"

    cd "$SCANNER_DIR"
    chmod +x "$CLIENT_BIN" 2>/dev/null
    nohup "$CLIENT_BIN" -config "./client_config.toml" < /dev/null >> "./client.log" 2>&1 &
    local scanner_pid=$!
    cd "$MASTER_DNS_DIR"

    printf "\n${GREEN}Scanner started (PID %d) on port 18009.${NC}\n" "$scanner_pid"

    while true; do
        clear_screen
        printf "%b\n\n" "$SCANNER_HEADER"
        printf "Domain:  ${CYAN}%s${NC}\n" "$domain"
        printf "Port:    ${CYAN}18009${NC}\n\n"

        local v=$(grep -E 'valid=[0-9]+' "$SCANNER_DIR/client.log" 2>/dev/null | tail -1 | sed -n 's/.*valid=\([0-9]\+\).*/\1/p' || echo 0)
        local r=$(grep -E 'rejected=[0-9]+' "$SCANNER_DIR/client.log" 2>/dev/null | tail -1 | sed -n 's/.*rejected=\([0-9]\+\).*/\1/p' || echo 0)
        local total_res=$(count_resolvers)
        local tested=$(( v + r ))
        local filled=$(( tested * 20 / total_res ))
        [[ $filled -gt 20 ]] && filled=20
        local empty=$(( 20 - filled ))
        local bar=""
        for ((i=0; i<filled; i++)); do bar+="█"; done
        for ((i=0; i<empty; i++)); do bar+="░"; done

        printf "Valid:    ${GREEN}%s${NC} | Rejected: ${RED}%s${NC} | Total: ${WHITE}%s${NC}\n" "$v" "$r" "$total_res"
        printf "Progress: [${CYAN}%s${NC}] %d/%d\n\n" "$bar" "$tested" "$total_res"

        if grep -q "SOCKS5 Proxy server is listening" "$SCANNER_DIR/client.log" 2>/dev/null; then
            printf "%b\n" "$SCANNER_COMPLETE_MSG"
            kill "$scanner_pid" 2>/dev/null
            break
        fi

        printf "%b\n" "$SCANNER_FOOTER"
        read -rsn1 -t 1 key
        case "$key" in
            q|Q) kill "$scanner_pid" 2>/dev/null; break ;;
            l|L)
                clear_screen; printf "── Scanner Log (Q to exit) ──\n\n"
                tail -n 50 -f "$SCANNER_DIR/client.log" 2>/dev/null & ltp=$!
                while read -rsn1 -t 0.5 lkey; do [[ "$lkey" == "q" || "$lkey" == "Q" ]] && { kill "$ltp" 2>/dev/null; break; }; done
                wait "$ltp" 2>/dev/null
                clear_screen
                ;;
            b|B)
                printf "\n"$SCANNER_BG_MSG"\n" "$scanner_pid"
                press_enter
                return
                ;;
        esac
    done

    local output_file="$SCANNER_DIR/masterdnsvpn_success_test.txt"
    local wait_cnt=0
    while [[ ! -f "$output_file" && $wait_cnt -lt 5 ]]; do
        sleep 1; ((wait_cnt++))
    done

    local healthy_count=0
    if [[ -f "$output_file" ]]; then
        healthy_count=$(grep -cve '^\s*$' "$output_file" 2>/dev/null || echo 0)
        cp "$output_file" "$MASTER_DNS_DIR/masterdnsvpn_success_test.txt" 2>/dev/null
    fi

    printf "\n${GREEN}${BOLD}The scanner found %d healthy resolvers.${NC}\n" "$healthy_count"
    printf "Do you want to save them as a new resolver list?\n"
    printf "  ${YELLOW}(y)es${NC} – enter a name and save\n"
    printf "  ${YELLOW}(n)o${NC}  – discard and return to menu\n"
    printf "Choose: "
    read -r save_choice
    if [[ "$save_choice" == "y" || "$save_choice" == "Y" ]]; then
        printf "%b\n" "$SCANNER_SAVE_NAME"
        read -r new_list_name
        if [[ -n "$new_list_name" ]]; then
            if [[ $healthy_count -gt 0 ]]; then
                cp "$output_file" "$RESOLVER_LISTS_DIR/${new_list_name}.txt"
            else
                touch "$RESOLVER_LISTS_DIR/${new_list_name}.txt"
            fi
            printf "\n"$SCANNER_LIST_SAVED"\n" "$new_list_name"
        fi
    fi
    press_enter
    rm -rf "$SCANNER_DIR"
}

resolver_menu() {
    while true; do
        clear_screen; printf "%b\n\n" "$RESOLVER_MENU_HEADER"
        printf "%b\n\n" "$RESOLVER_MENU"
        printf "\n%b" "$RESOLVER_MENU_PROMPT"
        read -rsn1 c
        case "$c" in
            1) printf "\n"; edit_file_with_education "$RESOLVERS_FILE"; auto_parallelism_enabled && update_all_configs_parallelism >/dev/null; check_resolvers_warning ;;
            2) printf "\n"; switch_resolver_list ;;
            3) printf "\n"; import_resolver_list ;;
            4) printf "\n"; delete_resolver_list ;;
            5) printf "\n"; resolver_scanner ;;
            6) return ;;
            h|H) printf "\n"; show_help_screen "Resolver Management: Edit, switch, import, delete lists, or run the auto‑scanner." ;;
            *) printf "\n%b\n" "$ERR_INVALID_CHOICE"; press_enter ;;
        esac
    done
}

#######################################
# 10. Settings
#######################################

settings_menu() {
    while true; do
        clear_screen; printf "%b\n\n" "$SETTINGS_HEADER"
        local auto_status; auto_parallelism_enabled && auto_status="${GREEN}ON${NC}" || auto_status="${RED}OFF${NC}"
        printf "$SETTINGS_MENU\n\n" "$PARALLELISM_PERCENT" "$auto_status"
        printf "%b" "$SETTINGS_PROMPT"
        read -rsn1 s_choice
        case "$s_choice" in
            1)
                printf "\n%b\n> " "$SETTINGS_PCT_PROMPT"
                read -r new_pct
                if [[ "$new_pct" =~ ^[0-9]+$ && $new_pct -ge 1 && $new_pct -le 100 ]]; then
                    PARALLELISM_PERCENT=$new_pct; echo "$PARALLELISM_PERCENT" > "$PARALLELISM_FILE"
                    printf "${GREEN}Percentage set to %d%%.${NC}\n" "$PARALLELISM_PERCENT"
                    auto_parallelism_enabled && update_all_configs_parallelism >/dev/null
                    press_enter
                else
                    printf "${RED}Invalid.${NC}\n"; press_enter
                fi
                ;;
            2)
                if auto_parallelism_enabled; then
                    set_auto_parallelism "no"
                    printf "\n${YELLOW}Auto‑manage turned OFF.${NC}\n"
                else
                    set_auto_parallelism "yes"
                    printf "\n${GREEN}Auto‑manage turned ON.${NC}\n"
                fi
                press_enter
                ;;
            3) backup_configs ;;
            4) restart_client ;;
            5)
                if has_valid_config; then
                    local domain=$(get_domain_from_config)
                    local key=$(get_key_from_config)
                    printf "\n"$SETTINGS_TUNNEL_INFO"\n" "$domain" "$key" "$(basename "$CONFIG_FILE")"
                else
                    printf "\n$SETTINGS_TUNNEL_NO_VALID\n"
                fi
                press_enter
                ;;
            6)
                > "$LOG_FILE"
                printf "\n$SETTINGS_LOG_CLEARED\n"
                press_enter
                ;;
            7) return ;;
            h|H) printf "\n"; show_help_screen "$SETTINGS_HELP" ;;
            *) printf "\n%b\n" "$ERR_INVALID_CHOICE"; press_enter ;;
        esac
    done
}

backup_configs() {
    local backup_name="masterdns_backup_$(date +%Y%m%d_%H%M%S).tar.gz"
    cd "$SCRIPT_DIR"
    tar -czf "$backup_name" Configuration/ 2>/dev/null
    if [[ -f "$backup_name" ]]; then
        printf "$SETTINGS_BACKUP_DONE\n" "$backup_name"
    else
        printf "%b\n" "$SETTINGS_BACKUP_FAILED"
    fi
    press_enter
}

#######################################
# 11. First-run
#######################################

first_run_check() {
    if ! has_valid_config; then
        printf "${YELLOW}You must create a profile first.${NC}\n"
        press_enter
        create_profile
    fi
    if [[ ! -f "$RESOLVERS_FILE" || ! -s "$RESOLVERS_FILE" ]]; then
        clear_screen; printf "%b\n\n" "$RESOLVERS_SETUP_HEADER"
        printf "%b\n\n" "$RESOLVERS_SETUP_PROMPT"
        read -rsn1 res_choice
        if [[ "$res_choice" == "y" || "$res_choice" == "Y" ]]; then
            touch "$RESOLVERS_FILE"
            edit_file_with_education "$RESOLVERS_FILE"
            printf "\n${WHITE}Enter a name to save this resolver list (or press Enter to skip):${NC}\n> "
            read -r list_name
            if [[ -n "$list_name" ]]; then
                cp "$RESOLVERS_FILE" "$RESOLVER_LISTS_DIR/${list_name}.txt"
                printf "${GREEN}Resolver list saved as '%s'.${NC}\n" "$list_name"
                press_enter
            fi
        fi
    fi
    [[ ! -f "$AUTO_MTU_FLAG" ]] && show_parallelism_setup
}

#######################################
# 12. MAIN LOOP
#######################################

[[ -f "$PARALLELISM_FILE" ]] && PARALLELISM_PERCENT=$(cat "$PARALLELISM_FILE")
[[ "$PARALLELISM_PERCENT" =~ ^[0-9]+$ ]] || PARALLELISM_PERCENT=10
(( PARALLELISM_PERCENT < 1 )) && PARALLELISM_PERCENT=1
(( PARALLELISM_PERCENT > 100 )) && PARALLELISM_PERCENT=100

first_run_check

draw_main_menu_static_with_bar
REFRESH_RATE=1

while true; do
    if is_running; then
        run_status=$(printf "$MSG_CLIENT_RUNNING" "$(cat "$PID_FILE")")
        if [[ "$(proxy_ready)" == "yes" ]]; then
            proxy_status=$(printf "$MSG_PROXY_READY" "$(get_active)" "$(get_stream)")
        else
            proxy_status=$(printf "$MSG_PROXY_WAITING" "$(get_valid)" "$(get_rejected)")
        fi
    else
        run_status="$MSG_CLIENT_STOPPED"
        proxy_status="$MSG_PROXY_INACTIVE"
    fi
    if auto_parallelism_enabled; then
        auto_par_status=$(printf "$MSG_AUTO_PAR_ON" "$PARALLELISM_PERCENT")
    else
        auto_par_status="$MSG_AUTO_PAR_OFF"
    fi

    if is_running; then
        valid=$(get_valid)
        rejected=$(get_rejected)
    else
        valid=0
        rejected=0
    fi
    total_res=$(count_resolvers)
    progress_bar=$(draw_progress_bar "$valid" "$rejected" "$total_res")

    save_cursor
    move_to 6 1; printf "%b${CLEAR_TO_EOL_ESC}" "$run_status"
    move_to 7 1; printf "%b${CLEAR_TO_EOL_ESC}" "$proxy_status"
    move_to 8 1; printf "%b${CLEAR_TO_EOL_ESC}" "$auto_par_status"
    move_to 9 1; printf "%b${CLEAR_TO_EOL_ESC}" "$progress_bar"
    move_to 12 1
    restore_cursor

    if read -rsn1 -t $REFRESH_RATE key 2>/dev/null; then
        [[ "$key" == "" ]] && continue
        case "$key" in
            1) printf "\n"; start_client ;;
            2) printf "\n"; stop_client ;;
            3) printf "\n"; edit_file_with_education "$CONFIG_FILE"; auto_parallelism_enabled && update_all_configs_parallelism >/dev/null ;;
            4) printf "\n"; resolver_menu ;;
            5) printf "\n"; show_log_view ;;
            6) printf "\n"; profile_menu ;;
            7) printf "\n"; start_mtu_speed_test ;;
            8) printf "\n"; multi_connection_menu ;;
            9) printf "\n"; start_resolver_health_check ;;
            0) printf "\n"; settings_menu ;;
            q|Q) printf "\n"; cleanup_on_exit ;;
            h|H) printf "\n"; show_main_help ;;
            *) printf "\r${CLEAR_TO_EOL_ESC}${RED}Invalid key.${NC}"; sleep 1; move_to 12 1; printf "${CLEAR_TO_EOL_ESC}" ;;
        esac
        draw_main_menu_static_with_bar
    fi
done