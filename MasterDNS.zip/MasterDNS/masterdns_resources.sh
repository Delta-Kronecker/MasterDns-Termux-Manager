#!/data/data/com.termux/files/usr/bin/bash
# =============================================================================
# MasterDnsVPN Client Manager – Text Resources & Helpers (v3.8)
# =============================================================================

# ── Terminal Control ────────────────────────────────────────────────────────
clear_screen()   { printf '\033[3J\033[H\033[2J'; }
hide_cursor()    { printf '\033[?25l'; }
show_cursor()    { printf '\033[?25h'; }
save_cursor()    { printf '\033[s'; }
restore_cursor() { printf '\033[u'; }
move_to()        { printf '\033[%d;%dH' "$1" "$2"; }

CLEAR_TO_EOL_ESC='\033[K'
CLEAR_TO_END_ESC='\033[J'

# ── Colours ─────────────────────────────────────────────────────────────────
RED='\e[1;31m'; GREEN='\e[1;32m'; YELLOW='\e[1;33m'
CYAN='\e[1;36m'; WHITE='\e[1;37m'; BOLD='\e[1m'; DIM='\e[2m'
NC='\e[0m'
SETTINGS_MENU=
# ── Box Characters ──────────────────────────────────────────────────────────
B_H="═"; B_V="║"; B_TL="╔"; B_TR="╗"; B_BL="╚"; B_BR="╝"
DASH="══════════════════════════════════════════════════"

# ═════════════════════════════════════════════════════════════════════════════
# 0. EDITOR HELP (Nano only)
# ═════════════════════════════════════════════════════════════════════════════

EDITOR_HELP="
${GREEN}╔═════════════════════════════╗${NC}
${GREEN}║ HOW TO EDIT & PASTE IN NANO ║${NC}
${GREEN}╚═════════════════════════════╝${NC}

This manager uses ${BOLD}nano${NC}. 

${BOLD}${GREEN}TO EDIT:${NC}
  • Move with arrow keys, edit normally.
  • ${BOLD}SAVE & exit:${NC}  ${YELLOW}Ctrl+X${NC} → ${YELLOW}Y${NC} → ${YELLOW}Enter${NC}
  • ${BOLD}DISCARD & exit:${NC} ${YELLOW}Ctrl+X${NC} → ${YELLOW}N${NC}

${BOLD}${GREEN}TO PASTE TEXT:${NC}
  ${WHITE}Long‑press on the screen${NC} → ${BOLD}Paste${NC}

${WHITE}Press ENTER to open the editor …${NC}"

show_editor_education() {
    clear_screen
    printf "%b\n\n" "$EDITOR_HELP"
    read -r
}

press_enter() {
    printf "\n${YELLOW}Press ENTER to continue…${NC}"
    read -r
}

# ═════════════════════════════════════════════════════════════════════════════
# 1. MAIN MENU (single‑column, instant keys)
# ═════════════════════════════════════════════════════════════════════════════

MAIN_HEADER="
${CYAN}╔════════════════════════════════════════╗${NC}
${CYAN}║   MasterDnsVPN Client Termux Manager   ║${NC}
${CYAN}╚════════════════════════════════════════╝${NC}"

MAIN_MENU_ITEMS="
${BOLD} 1.${NC} Start Client
${BOLD} 2.${NC} Stop Client
${BOLD} 3.${NC} Edit Current Profile
${BOLD} 4.${NC} Resolvers (lists & scanner)
${BOLD} 5.${NC} View Log
${BOLD} 6.${NC} Manage Profiles
${BOLD} 7.${NC} MTU Speed Test
${BOLD} 8.${NC} Multi‑Connection
${BOLD} 9.${NC} Resolver Health Check
${BOLD} 0.${NC} Settings
${BOLD} q.${NC} Exit
${BOLD} h.${NC} Help"

MAIN_FOOTER="
${DIM}Tip:${NC} Press ${YELLOW}h${NC} for help at any time.
${DIM}Editor:${NC} ${YELLOW}Ctrl+X Y Enter${NC} (save) | ${YELLOW}Ctrl+X N${NC} (discard)
${DIM}Log viewer:${NC} press ${YELLOW}Q${NC} to exit"

MAIN_PROMPT="Choose a key (1-9,0,q,h): "

# ═════════════════════════════════════════════════════════════════════════════
# 2. PROFILE CREATION & MANAGEMENT (compact listing, rich help)
# ═════════════════════════════════════════════════════════════════════════════

PROFILE_HEADER="${CYAN}══ Create Profile ══${NC}"
PROFILE_LIST="  0. Default
  1. mtu‑brute‑burst
  2. buffer‑smart‑ultra
  3. scan‑pool‑stable
  4. steady‑pool‑certified
  5. pure‑speed‑blade
  6. ironclad‑survivor
  7. universal‑harmony
  8. Create ALL profiles at once ${GREEN}${BOLD}★ Recommended ★${NC}
  9. Back"

PROFILE_HINT="
${GREEN}${BOLD}★★ Recommended workflow ★★${NC}
  Create all 8 profiles (option ${BOLD}8${NC}).
  Then from ${BOLD}Manage Profiles → Load${NC}, test options ${BOLD}1‑4${NC}.
  They deliver the best balance for most networks."

PROFILE_PROMPT="Choose [0-9, h for help]: "

PROFILE_HELP="
${CYAN}══ PROFILE REFERENCE ══${NC}
0. ${BOLD}Default${NC}

   Throughput: Medium | Resilience: Medium | MTU Flex: Moderate | Overhead: Low | Responsiveness: Moderate | Universality: High

   Balanced starter — safe, works anywhere.


1. ${BOLD}mtu-brute-burst${NC}

   Throughput: Ultra | Resilience: Medium | MTU Flex: Narrow | Overhead: Extreme | Responsiveness: Fast | Universality: Low

   Aggressive high‑MTU profile; massive window, heavy duplication — brute‑forces throughput.


2. ${BOLD}buffer-smart-ultra${NC}

   Throughput: Ultra | Resilience: Medium‑High | MTU Flex: Narrow | Overhead: High | Responsiveness: Moderate | Universality: Low

   Loss‑Then-Latency balancing, deep buffers, relaxed auto‑disable — smarter ultra‑throughput.


3. ${BOLD}scan-pool-stable${NC}

   Throughput: Medium | Resilience: High | MTU Flex: Wide | Overhead: Low | Responsiveness: Slow | Universality: High

   Discovers clean mid‑MTU pool; cautious failover, ZSTD download — daily stability.


4. ${BOLD}steady-pool-certified${NC}

   Throughput: Medium | Resilience: High | MTU Flex: Wide | Overhead: Very Low | Responsiveness: Moderate | Universality: Very High

   Validated resolver set, conservative RTO — steady throughput on any network.


5. ${BOLD}pure-speed-blade${NC}

   Throughput: Maximum | Resilience: Low | MTU Flex: Very Narrow | Overhead: None | Responsiveness: Aggressive | Universality: Very Low

   Zero duplication, massive window, zero compression — surgical speed for clean networks.


6. ${BOLD}ironclad-survivor${NC}

   Throughput: Very Low | Resilience: Maximum | MTU Flex: Universal | Overhead: Extreme | Responsiveness: Instant | Universality: Maximum

   Microscopic MTU, 4× duplication, monumental patience — never drops a packet.


7. ${BOLD}universal-harmony${NC}

   Throughput: Medium‑High | Resilience: Medium‑High | MTU Flex: Moderate | Overhead: Low | Responsiveness: Balanced | Universality: Maximum
   
   Mid‑MTU, Loss‑Then‑Latency, ZSTD — set‑and‑forget, works everywhere without tuning.


${GREEN}${BOLD}Quick picks 1‑4 usually give the best real‑world experience.${NC} Load and test them to find your ideal match.
${YELLOW} ${NC}"

render_profile_screen() {
    clear_screen
    printf "%b\n\n" "$PROFILE_HEADER"
    printf "%b\n\n" "$PROFILE_LIST"
    printf "%b\n" "$PROFILE_HINT"
    printf "\n%s" "$PROFILE_PROMPT"
}

GET_BASE_NAME_PROMPT="${WHITE}Enter a base name for the profile(s) (e.g. myconfig):${NC}"
FIRST_RUN_RECOMMENDED=

PROFILE_MENU="${CYAN}══ Manage Profiles ══${NC}\n\n  1. Create\n  2. Load\n  3. Delete\n  4. Back\n\nChoose [1-4, h]: "
LOAD_PROFILE_HEADER="${CYAN}══ Load Profile ══${NC}"
DELETE_PROFILE_HEADER="${CYAN}══ Delete Profile ══${NC}"

# ═════════════════════════════════════════════════════════════════════════════
# 3. MTU SPEED TEST
# ═════════════════════════════════════════════════════════════════════════════

MTU_INTRO_HELP="
${CYAN}══ MTU SPEED TEST – HOW IT WORKS ══${NC}

This test runs ${BOLD}6 different MTU configurations${NC} one after another.
For each range it:
  1. Starts a temporary client with a specific port (1800{1..6})
  2. Downloads a 2 MB file from Cloudflare through the tunnel
  3. Measures success / failure and records resolver stats

At the end you will see a comparison table.
${BOLD}The best range (most bytes downloaded) is highlighted.${NC}

${YELLOW}Press ENTER to proceed …${NC}"

MTU_INFO_BOX="
${CYAN}╔═══════════════════════════╗${NC}
${CYAN}║       MTU Speed Test      ║${NC}
${CYAN}╚═══════════════════════════╝${NC}"

MTU_INFO_TEXT="
${WHITE}Sequentially tests download speed for 6 MTU ranges.${NC}

  • Each range uses a separate proxy port (18001–18006)
  • Downloads a 2 MB file from Cloudflare through the tunnel
  • Displays live resolver statistics
  • [L] View log   [S] Skip current range   [Q] Abort whole test

${WHITE}Sample proxy for Hiddify:${NC}
  ${CYAN}socks://Og@127.0.0.1:18000#port=18000${NC}"

MTU_START_PROMPT="${YELLOW}Start the speed test? (y/n/h): ${NC}"

MTU_STEP_BOX="
${GREEN}╔═══════════════════════════════╗${NC}
${GREEN}║  MTU Speed Test – Step %d/6   ║${NC}
${GREEN}╚═══════════════════════════════╝${NC}"

MTU_RESULTS_HEADER="${CYAN}══ MTU Speed Test Results ══${NC}"
MTU_BEST_MSG="${GREEN}Best result: Port %d${NC} [UP:%d–%d DOWN:%d–%d] – %d bytes"

# ═════════════════════════════════════════════════════════════════════════════
# 4. RESOLVER HEALTH CHECK
# ═════════════════════════════════════════════════════════════════════════════

HEALTH_INTRO_HELP="
${CYAN}══ RESOLVER HEALTH CHECK – EXPLAINED ══${NC}

This tool sends many parallel requests through your ${BOLD}already running${NC} tunnel.
Weak or unstable resolvers will be automatically disabled by the client.

${BOLD}Two test types:${NC}
  1. Download a file of custom size (stresses throughput)
  2. TCP ping to Telegram (tests latency / connectivity)

${BOLD}What to observe:${NC}
  • Successful requests = ${GREEN}YES${NC}
  • Failed requests = ${RED}NO${NC}
  • Active resolvers count may drop as bad ones get disabled.

${YELLOW}Press ENTER to continue …${NC}"

HEALTH_INFO_BOX="
${CYAN}╔═══════════════════════════════════╗${NC}
${CYAN}║  Resolver Health Check & Cleaner  ║${NC}
${CYAN}╚═══════════════════════════════════╝${NC}"

HEALTH_INFO_TEXT="
${WHITE}This tool stress‑tests resolvers through the active tunnel.${NC}

  1. Sends parallel requests (Cloudflare download or Telegram ping)
  2. Weak resolvers are automatically disabled by the client
  3. Shows per‑request timing and live resolver count"

HEALTH_RUNNING_BOX="
${GREEN}╔════════════════════════╗${NC}
${GREEN}║  Resolver Health Chek  ║${NC}
${GREEN}╚════════════════════════╝${NC}"

HEALTH_SUMMARY_HEADER="${CYAN}══ Health Check Summary ══${NC}"

# ═════════════════════════════════════════════════════════════════════════════
# 5. MULTI‑CONNECTION
# ═════════════════════════════════════════════════════════════════════════════

MULTI_INTRO_HELP="
${CYAN}══ MULTI‑CONNECTION – QUICK GUIDE ══${NC}

You can run ${BOLD}multiple tunnel clients at the same time${NC}, each on its own port.
Two modes:
  1. ${BOLD}Different Profiles${NC} – test 8 profiles simultaneously to find the fastest.
  2. ${BOLD}Different MTU Ranges${NC} – compare 6 MTU ranges at once.

${BOLD}Proxy addresses${NC} are displayed after starting; add them to your app(s).
The dashboard shows live stats for each instance.

${YELLOW}Press ENTER to continue …${NC}"

MULTI_PROFILE_SELECT_HEADER="${CYAN}══ Multi‑Connection: Select Profiles ══${NC}"
MULTI_PROFILE_LIST="  0. Default                    4. steady‑pool‑certified
  1. mtu‑brute‑burst              5. pure‑speed‑blade
  2. buffer‑smart‑ultra           6. ironclad‑survivor
  3. scan‑pool‑stable            7. universal‑harmony"

MULTI_RUN_ALL="${YELLOW}Run ALL 8 profiles? (y/n): ${NC}"
MULTI_SELECT_GUIDE="${WHITE}Enter profile numbers separated by commas (e.g. 0,2,5,7):${NC}"
MULTI_DASHBOARD_HEADER="${GREEN}══ Multi‑Connection Dashboard ══${NC}"
MULTI_DASHBOARD_COLS="${WHITE}%-2s %-6s %-28s %8s %8s %8s %8s %6s${NC}"
MULTI_DASHBOARD_KEYS="${YELLOW}[V] View Log  [S] Stop All  [Q] Back to Menu${NC}"
MULTI_MENU="${CYAN}══ Multi‑Connection ══${NC}\n\n  1. Different Profiles (up to 8)\n  2. Different MTU Ranges (6)\n  3. Back\n\nChoose [1-3, h]: "
MULTI_CUSTOM_PAR="${YELLOW}Set a custom MTU_TEST_PARALLELISM for these instances?${NC}\n  (leave empty to keep their current value): "

# ═════════════════════════════════════════════════════════════════════════════
# 6. SETTINGS
# ═════════════════════════════════════════════════════════════════════════════

SETTINGS_HELP="
${CYAN}══ SETTINGS EXPLAINED ══${NC}

${BOLD}1. MTU parallelism${NC} – how many resolvers are tested at once.
${BOLD}2. Toggle auto‑manage${NC} – adjust based on resolver count.
${BOLD}3. Backup${NC} – saves all your configs and profiles.
${BOLD}4. Restart Client${NC} – stop + start.
${BOLD}5. Show tunnel info${NC} – domain & key status.
${BOLD}6. Clear client log${NC} – delete the current log file.
${BOLD}7. Back${NC} – return to main menu.

${YELLOW}Press ENTER to go back …${NC}"

SETTINGS_HEADER="${CYAN}══ Settings ══${NC}"
SETTINGS_MENU="  1. Change MTU parallelism percentage (currently ${GREEN}%d%%${NC})
  2. Toggle auto‑manage parallelism (currently %b)
  3. Backup all configurations
  4. Restart Client (Stop + Start)
  5. Show tunnel info
  6. Clear client log
  7. Back"
SETTINGS_PROMPT="Choose [1-7, h]: "
SETTINGS_PCT_PROMPT="${WHITE}Enter new percentage (1–100):${NC}"
SETTINGS_BACKUP_DONE="${GREEN}Backup created: %s${NC}"
SETTINGS_BACKUP_FAILED="${RED}Backup failed!${NC}"
SETTINGS_RESTARTING="${YELLOW}Restarting client…${NC}"
SETTINGS_TUNNEL_INFO="
${CYAN}══ Current Tunnel Info ══${NC}
${BOLD}Domain:${NC}        %s
${BOLD}Encryption Key:${NC} %s
${BOLD}Profile:${NC}       %s
${BOLD}Configuration:${NC} valid"
SETTINGS_TUNNEL_NO_VALID="${RED}No valid configuration found.${NC}"
SETTINGS_LOG_CLEARED="${GREEN}Client log cleared.${NC}"

# ═════════════════════════════════════════════════════════════════════════════
# 7. FIRST‑RUN PROMPTS
# ═════════════════════════════════════════════════════════════════════════════

PARALLELISM_SETUP_HEADER="${CYAN}══ MTU Parallelism Auto‑Management ══${NC}"
PARALLELISM_SETUP_PROMPT="${WHITE}Auto‑manage MTU_TEST_PARALLELISM based on resolver count?${NC}\n${YELLOW}(y/n/h): ${NC}"

PARALLELISM_HELP="
${CYAN}══ AUTO‑MANAGE PARALLELISM – WHAT IT DOES ══${NC}

When ${BOLD}enabled${NC}, the manager will automatically set MTU_TEST_PARALLELISM
to ${BOLD}${PARALLELISM_PERCENT}%%${NC} of your resolver count (minimum 1).
This keeps the MTU test fast without overloading your device.

You can always change it later in Settings.

${YELLOW}Press ENTER …${NC}"

RESOLVERS_SETUP_HEADER="${CYAN}══ Resolvers Setup ══${NC}"
RESOLVERS_SETUP_PROMPT="${YELLOW}Do you want to enter your resolver list now?${NC}
  ${GREEN}y${NC} – open the editor
  ${YELLOW}n${NC} – skip (add later via Menu → Resolvers)
  ${CYAN}h${NC} – help"

# ═════════════════════════════════════════════════════════════════════════════
# 8. RESOLVER MANAGEMENT (lists & scanner)
# ═════════════════════════════════════════════════════════════════════════════

RESOLVER_MENU_HEADER="${CYAN}══ Resolver Management ══${NC}"
RESOLVER_MENU="  1. Edit current resolver list
  2. Switch to a different list
  3. Import / add a new list
  4. Delete a saved list
  5. ${GREEN}Scanner: auto‑discover working resolvers${NC}
  6. Back"
RESOLVER_MENU_PROMPT="Choose [1-6, h]: "

RESOLVER_SELECT_HEADER="${CYAN}══ Select Resolver List ══${NC}"
RESOLVER_NO_LISTS="${YELLOW}No saved resolver lists found.${NC}"

RESOLVER_IMPORT_MENU="
${WHITE}How would you like to add resolvers?${NC}
  1. Paste manually (Ctrl+D to finish)
  2. Pick a .txt file from storage
  3. Back"

RESOLVER_ADD_NAME="${WHITE}Name for the new list (e.g. home_resolvers):${NC}"
RESOLVER_ADD_SOURCE="${WHITE}Paste the resolver IPs (one per line). Press ${YELLOW}Ctrl+D${NC} when done.${NC}"
RESOLVER_FILE_COPIED="${GREEN}File copied and list saved.${NC}"
RESOLVER_TERMUXAPI_MISSING="${RED}Termux:API is required for file picking.${NC}\n  Install: ${YELLOW}pkg install termux-api${NC}"

RESOLVER_DELETED="${GREEN}List deleted.${NC}"

SCANNER_INTRO_HELP="
${CYAN}══ RESOLVER SCANNER – HOW IT WORKS ══${NC}

This tool launches a special client that scans ${BOLD}all resolvers${NC} in the
current active list and records the healthy ones.

${BOLD}Key points:${NC}
  • Uses a separate port (18009) – won't interfere with your main proxy.
  • Automatically stops when the scanning is complete (proxy ready).
  • You can stop early with ${YELLOW}Q${NC}; partial results will still be saved.
  • Afterwards you can add the discovered resolvers as a new list.

${YELLOW}Press ENTER to start the scanner …${NC}"

SCANNER_HEADER="${GREEN}══ Resolver Scanner – Live ══${NC}"
SCANNER_FOOTER="${YELLOW}[Q] Stop & save  [L] View log  [B] Return to menu (keep scanning)${NC}"
SCANNER_COMPLETE_MSG="${GREEN}Scanning complete!${NC}"

SCANNER_SAVE_PROMPT="
${GREEN}${BOLD}The scanner found %d healthy resolvers.${NC}
Do you want to save them as a new resolver list?
  ${YELLOW}(y)es${NC} – enter a name and save
  ${YELLOW}(n)o${NC}  – discard and return to menu
Choose: "

SCANNER_SAVE_NAME="${WHITE}Enter a name for the new resolver list:${NC}"
SCANNER_LIST_SAVED="${GREEN}Resolver list '%s' saved successfully.${NC}"

SCANNER_BG_MSG="${DIM}Scanner running in background (PID %s).${NC}"

# ═════════════════════════════════════════════════════════════════════════════
# 9. STATUS MESSAGES & PROGRESS BAR
# ═════════════════════════════════════════════════════════════════════════════

MSG_CLIENT_RUNNING="Status: ${GREEN}Running${NC} (PID %s)"
MSG_CLIENT_STOPPED="Status: ${RED}Stopped${NC}"
MSG_PROXY_READY="Proxy:  ${GREEN}Ready${NC}  |  Active resolvers: ${GREEN}%s${NC}  |  Streams: ${CYAN}%s${NC}"
MSG_PROXY_WAITING="Proxy:  ${YELLOW}Waiting…${NC}  |  Valid: ${GREEN}%s${NC}  |  Rejected: ${RED}%s${NC}"
MSG_PROXY_INACTIVE="Proxy:  ${RED}Not active${NC}"
MSG_AUTO_PAR_ON="Auto Parallelism: ${GREEN}ON${NC} (%d%%)"
MSG_AUTO_PAR_OFF="Auto Parallelism: ${RED}OFF${NC}"

MSG_DONE="${GREEN}Done!${NC}"
MSG_STARTED="${GREEN}Started${NC}"
MSG_LOADED="${GREEN}Loaded!${NC}"
MSG_DELETED="${GREEN}Deleted!${NC}"
MSG_STOPPING_ALL="${RED}Stopping all instances…${NC}"
MSG_ALL_STOPPED="${GREEN}All stopped.${NC}"
MSG_PAR_UPDATED="${GREEN}Parallelism updated: %d${NC}"

ERR_FOLDER_NOT_FOUND="${RED}Error: Configuration/ folder not found.${NC}"
ERR_BINARY_NOT_FOUND="${RED}Binary not found.${NC}"
ERR_NO_CONFIG="${RED}No valid config.${NC}"
ERR_NO_RESOLVERS="${RED}No resolvers.${NC}"
ERR_NEED_CURL="${RED}Need curl: pkg install curl${NC}"
ERR_CLIENT_NOT_RUNNING="${RED}Client is not running!${NC}"
ERR_PROXY_NOT_READY="${RED}Proxy not ready after 60s. Aborting.${NC}"
ERR_INVALID_CHOICE="${RED}Invalid choice.${NC}"
ERR_INVALID_NUMBER="${RED}Invalid number.${NC}"
ERR_REQUIRED="${RED}Required!${NC}"
ERR_TEMPLATE_NOT_FOUND="${RED}%s not found!${NC}"
ERR_NO_PROFILES="${YELLOW}No profiles found.${NC}"
ERR_NO_VALID_SELECTION="${RED}No valid profiles selected. Aborting.${NC}"
ERR_MISSING_DOMAIN_KEY="${RED}Active profile lacks valid domain/key.${NC}"
ERR_NANO_NOT_FOUND="${RED}nano not found! Install with: pkg install nano${NC}"

INFO_STOPPING="${YELLOW}Stopping client…${NC}"
INFO_PROXY_WAITING="${YELLOW}Proxy not ready yet. Waiting…${NC}"
INFO_PROXY_READY_NOW="${GREEN}Proxy is now ready!${NC}"
INFO_CREATING_ALL="${GREEN}Creating all 8 profiles with prefix: %s${NC}"
INFO_SKIP_EXISTING="${YELLOW}Skipping existing profile: %s${NC}"
INFO_CREATED="${GREEN}Created: %s${NC}"

# ═════════════════════════════════════════════════════════════════════════════
# 10. HELPER FUNCTIONS
# ═════════════════════════════════════════════════════════════════════════════

print_divider() { printf "${CYAN}%s${NC}\n" "$DASH"; }
print_mtu_step_box() { local step=$1; printf "$MTU_STEP_BOX\n" "$step"; }
print_multi_col_headers() { printf "$MULTI_DASHBOARD_COLS\n" "#" "Port" "Profile" "Valid" "Reject" "Active" "Stream" "Proxy"; }

show_help_screen() {
    local text="$1"
    clear_screen
    printf "%b\n\n" "$text"
    press_enter
}

draw_progress_bar() {
    local valid=$1 rejected=$2 total=$3 width=20
    [[ $total -le 0 ]] && total=1
    local tested=$(( valid + rejected ))
    local filled=$(( tested * width / total ))
    [[ $filled -gt $width ]] && filled=$width
    local empty=$(( width - filled ))
    local bar=""
    for ((i=0; i<filled; i++)); do bar+="█"; done
    for ((i=0; i<empty; i++)); do bar+="░"; done
    printf "Tested: [${CYAN}%s${NC}] %d/%d" "$bar" "$tested" "$total"
}

draw_main_menu_static_with_bar() {
    clear_screen
    printf "%b\n\n" "$MAIN_HEADER"
    printf "\n\n\n\n"
    printf "%b\n\n" "$MAIN_MENU_ITEMS"
    printf "%b\n\n" "$MAIN_FOOTER"
    printf "%b" "$MAIN_PROMPT"
}

MAIN_HELP="
${CYAN}══ MAIN MENU HELP ══${NC}

${BOLD}1. Start Client${NC} – launch the tunnel.
${BOLD}2. Stop Client${NC} – stop the current tunnel.
${BOLD}3. Edit Current Profile${NC} – modify the active ${BOLD}client_config.toml${NC}.
${BOLD}4. Resolvers${NC} – manage resolver lists and run the auto‑scanner.
${BOLD}5. View Log${NC} – tail the live client log; press ${YELLOW}Q${NC} to exit.
${BOLD}6. Manage Profiles${NC} – create, load, or delete profiles.
${BOLD}7. MTU Speed Test${NC} – find the best MTU values for your network.
${BOLD}8. Multi‑Connection${NC} – run multiple tunnel instances simultaneously.
${BOLD}9. Resolver Health Check${NC} – stress‑test your resolver pool.
${BOLD}0. Settings${NC} – adjust parallelism, backup, restart, show info.
${BOLD}q. Exit${NC} – quit the manager.
${BOLD}h.${NC} – show this help.

${YELLOW}Press ENTER to return …${NC}"

show_main_help() { show_help_screen "$MAIN_HELP"; }
